local tl = require('track_light')
local lhud = require('lights_hud')
local slMgr = {}

local hud_scale = 1.0
local orientation = 'vertical' -- 'vertical' or 'horizontal'
local sendChatMessage = false
local TLConnectorKey = ac.getCarID(0) .. "_trafficLights"
local TLConnectorSharedData = {
    ac.StructItem.key(TLConnectorKey .. "_" .. 0),
    Connected = ac.StructItem.boolean(),
    Started = ac.StructItem.boolean(),
    Light1On = ac.StructItem.boolean(),
    Light2On = ac.StructItem.boolean(),
    Light3On = ac.StructItem.boolean(),
    Light4On = ac.StructItem.boolean(),
    YellowBlinking = ac.StructItem.boolean(),
}
local TLightsConnection = ac.connect(TLConnectorSharedData, false, ac.SharedNamespace.Shared)
TLightsConnection.Connected = true

function slMgr.setOrientation(new_orientation)
    if new_orientation == 'vertical' or new_orientation == 'horizontal' then
        orientation = new_orientation
    else
        error("Invalid orientation. Use 'vertical' or 'horizontal'.")
    end
end

local modType
function slMgr.set3DModType(type)
    modType = type
end

local sound = nil
local soundsBasePath = ""
local function resetSoundsAndPlay(soundName)
    if sound then
        sound:stop()
        sound:dispose()
    end
    local soundPath = soundsBasePath .. "sounds/" .. soundName .. ".mp3"
    sound = ac.AudioEvent.fromFile({ filename = soundPath, use3D = false, loop = false }, false)
    sound.cameraExteriorMultiplier = 1
    sound.cameraInteriorMultiplier = 1
    sound.cameraTrackMultiplier = 1
    sound:start()
end

local currentTime = 0

local start_lights_timer = 0
local start_lights_state = 0
local start_lights_running = false

local show_start_lights = false

local greenLightTimer = 0
local isYellowBlinking = false
local blinkTimer = 0
local blinkInterval = 1.0
local blinkLightsOn = false
local greenLightDuration = 2
local useSound = false
local useClassicLightsHUD = true
local use3DLights = true
local isInitiator = false
local trackLightEdition = false
local serverMode = false
---comment
---@param classicLightsScale number
---@param sound boolean
---@param classicLightsOrientation string
---@param lightsModType tl.LightType
---@param chatMessage boolean
---@param mod3d boolean
---@param server? boolean
function slMgr.init(classicLightsScale, sound, classicLightsOrientation, lightsModType, chatMessage, mod3d, server)
    slMgr.setScale(classicLightsScale)
    slMgr.setUseSound(sound)
    slMgr.setOrientation(classicLightsOrientation)
    slMgr.set3DModType(lightsModType)
    slMgr.setSendChatMessage(chatMessage)
    slMgr.setUse3DLights(mod3d)
    tl.init(lightsModType, false, server)
    serverMode = server
    if serverMode then
        web.loadRemoteAssets("https://github.com/Dasde/Start_Lights_updates/raw/refs/heads/main/sounds.zip",
            function(err, folder)
                soundsBasePath = folder .. "\\"
            end)
    end
end

function slMgr.setUseSound(enabled)
    useSound = enabled
end

function slMgr.setUseClassicLightsHUD(enabled)
    useClassicLightsHUD = enabled
end

function slMgr.setUse3DLights(enabled)
    use3DLights = enabled
end

function slMgr.setSendChatMessage(enabled)
    sendChatMessage = enabled
end

function slMgr.trackLightEdition(enabled)
    trackLightEdition = enabled
end

function slMgr.rotateTrackLights(angle)
    tl.rotateTrackLights(angle)
end

function slMgr.getTrackLightsRotation()
    return tl.getTrackLightsRotation()
end

function slMgr.setAndSaveTrackLights(pos, rotation)
    if tl.getTrackLightPosition() == pos and tl.getTrackLightsRotation() == rotation then return end
    tl.setTrackLightPosition(pos)
    tl.setTrackLightsRotation(rotation)
    if not serverMode then
        tl.saveTrackLights()
    end
    if not tl.trackHasLightMesh() then
        if serverMode then
            tl.displayLightMesh(modType, true)
        else
            tl.init(modType, false)
        end
    else
        tl.rotateTrackLights(rotation)
    end
end

function slMgr.getTrackLightConfig()
    local pos = tl.getTrackLightPosition()
    return string.format("[TRACK_START_LIGHT]\nTRACK=%s\nX=%f\nY=%f\nZ=%f\nROT=%f", ac.getTrackFullID(), pos.x, pos.y,
        pos.z, tl.getTrackLightsRotation())
end

function slMgr.saveTrackLights()
    tl.saveTrackLights(serverMode)
end

function slMgr.reloadTrackLights(force)
    tl.reloadTrackLights(modType, force, serverMode)
end

function slMgr.clearSavedLights()
    tl.clearSavedLights(serverMode)
end

function slMgr.SetIsYellowBlinking(isBlinking)
    isYellowBlinking = isBlinking
    if isBlinking then
        blinkTimer = 0
        lhud.displayLights()
        start_lights_running = true
        TLightsConnection.YellowBlinking = true
        if not tl.trackHasLightMesh() and use3DLights then
            tl.displayLightMeshAheadCar(modType, serverMode)
        end
        tl.setTrackLightColor(tl.getLightId(1), tl.TrackLightColors.orange)
        tl.setTrackLightColor(tl.getLightId(2), tl.TrackLightColors.orange)
        tl.setTrackLightColor(tl.getLightId(3), tl.TrackLightColors.orange)
        if (tl.getLightCount() > 3) then
            tl.setTrackLightColor(tl.getLightId(4), tl.TrackLightColors.orange)
        end
        start_lights_state = 0
        start_lights_timer = 0
        if useSound then
            resetSoundsAndPlay("longBeep")
        end
    else
        start_lights_running = false
        TLightsConnection.YellowBlinking = false
        tl.setTrackLightColor(tl.getLightId(1), tl.TrackLightColors.off)
        tl.setTrackLightColor(tl.getLightId(2), tl.TrackLightColors.off)
        tl.setTrackLightColor(tl.getLightId(3), tl.TrackLightColors.off)
        if (tl.getLightCount() > 3) then
            tl.setTrackLightColor(tl.getLightId(4), tl.TrackLightColors.off)
        end
        if not tl.trackHasLightMesh() then
            tl.removeLightMesh()
        end
    end
    TLightsConnection.Started = false
    TLightsConnection.Light1On = false
    TLightsConnection.Light2On = false
    TLightsConnection.Light3On = false
    TLightsConnection.Light4On = false
end

function slMgr.isYellowBlinking()
    return isYellowBlinking
end

function slMgr.isStartLightsActive()
    return start_lights_running
end

function slMgr.setStartLightsVisible(visible)
    show_start_lights = visible
end

function slMgr.stopStartLights()
    lhud.hideLights()
    start_lights_running = false
    TLightsConnection.Started = false
    TLightsConnection.Light1On = false
    TLightsConnection.Light2On = false
    TLightsConnection.Light3On = false
    TLightsConnection.Light4On = false
    tl.turnOffLights()
    start_lights_state = 0
    start_lights_timer = 0
    show_start_lights = false
end

function slMgr.triggerStartLights(greenDuration, _isInitiator)
    isInitiator = _isInitiator
    if greenDuration then
        greenLightDuration = greenDuration
    else
        greenLightDuration = 2 -- default duration if not provided
    end
    start_lights_running = true
    TLightsConnection.Started = true
    TLightsConnection.Light1On = false
    TLightsConnection.Light2On = false
    TLightsConnection.Light3On = false
    TLightsConnection.Light4On = false
    start_lights_state = 0
    start_lights_timer = 0
    show_start_lights = true

    if not tl.trackHasLightMesh() and use3DLights then
        tl.displayLightMeshAheadCar(modType, serverMode)
    end

    lhud.hideLights()

    greenLightTimer = 0
    isYellowBlinking = false
    blinkTimer = 0

    if sendChatMessage and isInitiator then
        ac.sendChatMessage("[StartLights] Get Ready")
    end
end

function slMgr.updateStartLights(dt)
    if trackLightEdition then
        tl:enableEditionMode(dt, modType, serverMode)
    end
    if not start_lights_running then
        return
    end
    if isYellowBlinking then
        show_start_lights = true
        blinkTimer = blinkTimer + dt
        if blinkTimer >= blinkInterval then
            blinkTimer = 0
            blinkLightsOn = not blinkLightsOn
            local newAlpha = blinkLightsOn and 0 or 1
            if newAlpha == 1 and useSound then
                resetSoundsAndPlay("longBeep")
            end

            lhud.configureLights(newAlpha, 1, true)
            tl.setTrackLightColor(tl.getLightId(1),
                newAlpha == 1 and tl.TrackLightColors.orange or tl.TrackLightColors.off)
            tl.setTrackLightColor(tl.getLightId(2),
                newAlpha == 1 and tl.TrackLightColors.orange or tl.TrackLightColors.off)
            tl.setTrackLightColor(tl.getLightId(3),
            newAlpha == 1 and tl.TrackLightColors.orange or tl.TrackLightColors.off)
            if (tl.getLightCount() > 3) then
                tl.setTrackLightColor(tl.getLightId(4),
                    newAlpha == 1 and tl.TrackLightColors.orange or tl.TrackLightColors.off)
            end
        end
    else
        if start_lights_state < 4 then
            start_lights_timer = start_lights_timer + dt

            if start_lights_timer >= 1 then
                start_lights_timer = 0
                start_lights_state = start_lights_state + 1
                if useSound then
                    if start_lights_state < 4 then
                        resetSoundsAndPlay("shortBeep")
                    else
                        resetSoundsAndPlay("longBeep")
                    end
                end
                if sendChatMessage and isInitiator then
                    if start_lights_state < 4 then
                        ac.sendChatMessage(string.format("[StartLights] %d", start_lights_state))
                    else
                        ac.sendChatMessage("[StartLights] Go!")
                    end
                end
                if start_lights_state <= 4 then
                    lhud.configureLight(start_lights_state, 0, 0.5, true)
                else
                    start_lights_running = false
                    start_lights_state = 0
                    start_lights_timer = 0
                end
            end
        end
        show_start_lights = start_lights_running
        lhud.fadeInLights(dt)
        if start_lights_state == 4 then
            greenLightTimer = greenLightTimer + dt
            if greenLightTimer >= greenLightDuration then
                start_lights_state = 5
                lhud.hideLights() -- scale 1 ?
                start_lights_running = false
                TLightsConnection.Started = false
                if not tl.trackHasLightMesh() then
                    tl.removeLightMesh()
                end
            end
        end
        if start_lights_state >= 1 and start_lights_state < 4 then
            TLightsConnection.Light1On = true
            tl.setTrackLightColor(tl.getLightId(1), tl.TrackLightColors.orange)
        else
            TLightsConnection.Light1On = false
            tl.setTrackLightColor(tl.getLightId(1), tl.TrackLightColors.off)
        end
        if start_lights_state >= 2 and start_lights_state < 4 then
            TLightsConnection.Light2On = true
            tl.setTrackLightColor(tl.getLightId(2), tl.TrackLightColors.orange)
        else
            TLightsConnection.Light2On = false
            tl.setTrackLightColor(tl.getLightId(2), tl.TrackLightColors.off)
        end
        if start_lights_state >= 3 and start_lights_state < 4 then
            TLightsConnection.Light3On = true
            tl.setTrackLightColor(tl.getLightId(3), tl.TrackLightColors.orange)
        else
            TLightsConnection.Light3On = false
            tl.setTrackLightColor(tl.getLightId(3), tl.TrackLightColors.off)
        end
        local nbLights = tl.getLightCount()
        if start_lights_state == 4 then
            TLightsConnection.Light4On = true
            if (nbLights < 4) then
                tl.setTrackLightColor(tl.getLightId(1), tl.TrackLightColors.green)
                tl.setTrackLightColor(tl.getLightId(2), tl.TrackLightColors.green)
                tl.setTrackLightColor(tl.getLightId(3), tl.TrackLightColors.green)
            else
                tl.setTrackLightColor(tl.getLightId(4), tl.TrackLightColors.green)
            end
        else
            TLightsConnection.Light4On = false
            if (nbLights > 3) then
                tl.setTrackLightColor(tl.getLightId(4), tl.TrackLightColors.off)
            end
        end
    end
end

function slMgr.draw()
    if show_start_lights and useClassicLightsHUD then
        lhud.draw(orientation, hud_scale, start_lights_state, isYellowBlinking)
    end
end

function slMgr.drawMiniHUD()
    local ratio = ui.windowWidth() / 300
    lhud.draw("horizontal", ratio, start_lights_state, isYellowBlinking)
end

function slMgr.setScale(scale)
    hud_scale = scale
end

function slMgr.getScale()
    return hud_scale
end

function slMgr.updateTime(dt)
    currentTime = currentTime + dt
end

function slMgr.trackHasLightMesh()
    return tl.trackHasLightMesh()
end

function slMgr.trackHasEmbedLightMesh()
    return tl.trackHasEmbedLightMesh()
end

function slMgr.getTrackLightPosition()
    return tl.getTrackLightPosition()
end

function slMgr.disposeLightMesh()
    tl.removeLightMesh()
end

return slMgr
