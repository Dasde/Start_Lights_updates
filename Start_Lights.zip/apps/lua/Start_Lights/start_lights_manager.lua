local tl = require('track_light')
local lhud = require('lights_hud')
local startLightsManager = {}

local hud_scale = 1.0
local orientation = 'vertical' -- 'vertical' or 'horizontal'
local sendChatMessage = false
local TLKey = ac.getCarID(0) .. "_trafficLights"
local TLSharedData = {
    ac.StructItem.key(TLKey .. "_" .. 0),
    Connected = ac.StructItem.boolean(),
    Started = ac.StructItem.boolean(),
    Light1On = ac.StructItem.boolean(),
    Light2On = ac.StructItem.boolean(),
    Light3On = ac.StructItem.boolean(),
    Light4On = ac.StructItem.boolean(),
    YellowBlinking = ac.StructItem.boolean(),
}
TLightsConnection = ac.connect(TLSharedData, false, ac.SharedNamespace.Shared)
TLightsConnection.Connected = true

function startLightsManager.setOrientation(new_orientation)
    if new_orientation == 'vertical' or new_orientation == 'horizontal' then
        orientation = new_orientation
    else
        error("Invalid orientation. Use 'vertical' or 'horizontal'.")
    end
end
local modType
function startLightsManager.set3DModType(type)
    modType = type
end

local sound = nil
local function resetSoundsAndPlay(soundName)
    if sound then
        sound:stop()
        sound:dispose()
    end
    local soundPath = "sounds/" .. soundName .. ".mp3"
    sound = ac.AudioEvent.fromFile({ filename = soundPath, use3D = false, loop = false }, false)
    sound.cameraExteriorMultiplier = 1
    sound.cameraInteriorMultiplier = 1
    sound.cameraTrackMultiplier = 1
    sound:start()
end

local currentTime = 0

local start_lights_timer = 0
local start_lights_state = 0
local start_lights_running = false

local show_start_lights = false

local greenLightTimer = 0
local isYellowBlinking = false
local blinkTimer = 0
local blinkInterval = 1.0
local blinkLightsOn = false
local greenLightDuration = 2
local useSound = false
local useClassicLightsHUD = true
local use3DLights = true
local isInitiator = false
local trackLightEdition = false

function startLightsManager.init(classicLightsScale, useSound, classicLightsOrientation, lightsModType, sendChatMessage)
    startLightsManager.setScale(classicLightsScale)
    startLightsManager.setUseSound(useSound)
    startLightsManager.setOrientation(classicLightsOrientation)
    startLightsManager.set3DModType(lightsModType)
    startLightsManager.setSendChatMessage(sendChatMessage)
    tl.init(lightsModType)
end

function startLightsManager.setUseSound(enabled)
    useSound = enabled
end

function startLightsManager.setUseClassicLightsHUD(enabled)
    useClassicLightsHUD = enabled
end

function startLightsManager.setUse3DLights(enabled)
    use3DLights = enabled
end

function startLightsManager.setSendChatMessage(enabled)
    sendChatMessage = enabled
end

function startLightsManager.trackLightEdition(enabled)
    trackLightEdition = enabled
end

function startLightsManager.rotateTrackLights(angle)
    tl.rotateTrackLights(angle)
end

function startLightsManager.getTrackLightsRotation()
    return tl.getTrackLightsRotation()
end

function startLightsManager.setAndSaveTrackLights(pos, rotation)
    if tl.getTrackLightPosition() == pos and tl.getTrackLightsRotation() == rotation then return end
    tl.setTrackLightPosition(pos)
    tl.setTrackLightsRotation(rotation)
    tl.saveTrackLights()
    tl.init(modType)
end

function startLightsManager.saveTrackLights()
    tl.saveTrackLights()
end

function startLightsManager.reloadTrackLights()
    tl.init(modType)
end

function startLightsManager.SetIsYellowBlinking(isBlinking)
    isYellowBlinking = isBlinking
    if isBlinking then
        blinkTimer = 0
        lhud.displayLights()
        start_lights_running = true
        TLightsConnection.YellowBlinking = true
        if not tl.trackHasLightMesh() and use3DLights then
            tl.displayLightMesh(modType)
        end
        tl.setTrackLightColor(1, tl.TrackLightColors.orange)
        tl.setTrackLightColor(2, tl.TrackLightColors.orange)
        tl.setTrackLightColor(3, tl.TrackLightColors.orange)
        if (tl.getLightCount() > 3) then
            tl.setTrackLightColor(4, tl.TrackLightColors.orange)
        end
        start_lights_state = 0
        start_lights_timer = 0
        if useSound then
            resetSoundsAndPlay("longBeep")
        end
    else
        start_lights_running = false
        TLightsConnection.YellowBlinking = false
        tl.setTrackLightColor(1, tl.TrackLightColors.off)
        tl.setTrackLightColor(2, tl.TrackLightColors.off)
        tl.setTrackLightColor(3, tl.TrackLightColors.off)
        if (tl.getLightCount() > 3) then
            tl.setTrackLightColor(4, tl.TrackLightColors.off)
        end
        tl.removeLightMesh()
    end
    TLightsConnection.Started = false
    TLightsConnection.Light1On = false
    TLightsConnection.Light2On = false
    TLightsConnection.Light3On = false
    TLightsConnection.Light4On = false
end

function startLightsManager.isYellowBlinking()
    return isYellowBlinking
end

function startLightsManager.isStartLightsActive()
    return start_lights_running
end

function startLightsManager.setStartLightsVisible(visible)
    show_start_lights = visible
end

function startLightsManager.stopStartLights()
    lhud.hideLights()
    start_lights_running = false
    TLightsConnection.Started = false
    TLightsConnection.Light1On = false
    TLightsConnection.Light2On = false
    TLightsConnection.Light3On = false
    TLightsConnection.Light4On = false
    tl.turnOffLights()
    start_lights_state = 0
    start_lights_timer = 0
    show_start_lights = false
end

function startLightsManager.triggerStartLights(greenDuration, _isInitiator)
    isInitiator = _isInitiator
    if greenDuration then
        greenLightDuration = greenDuration
    else
        greenLightDuration = 2 -- default duration if not provided
    end
    start_lights_running = true
    TLightsConnection.Started = true
    TLightsConnection.Light1On = false
    TLightsConnection.Light2On = false
    TLightsConnection.Light3On = false
    TLightsConnection.Light4On = false
    start_lights_state = 0
    start_lights_timer = 0
    show_start_lights = true

    if not tl.trackHasLightMesh() and use3DLights then
        tl.displayLightMesh(modType)
    end

    lhud.hideLights()

    greenLightTimer = 0
    isYellowBlinking = false
    blinkTimer = 0
end

function startLightsManager.updateStartLights(dt)
    if trackLightEdition then
        tl:enableEditionMode(dt, modType)
    end
    if not start_lights_running then
        return
    end
    if isYellowBlinking then
        show_start_lights = true
        blinkTimer = blinkTimer + dt
        if blinkTimer >= blinkInterval then
            blinkTimer = 0
            blinkLightsOn = not blinkLightsOn
            local newAlpha = blinkLightsOn and 0 or 1
            if newAlpha == 1 and useSound then
                resetSoundsAndPlay("longBeep")
            end

            lhud.configureLights(newAlpha, 1, true)
            tl.setTrackLightColor(1, newAlpha == 1 and tl.TrackLightColors.orange or tl.TrackLightColors.off)
            tl.setTrackLightColor(2, newAlpha == 1 and tl.TrackLightColors.orange or tl.TrackLightColors.off)
            tl.setTrackLightColor(3, newAlpha == 1 and tl.TrackLightColors.orange or tl.TrackLightColors.off)
        end
    else
        if start_lights_state < 4 then
            start_lights_timer = start_lights_timer + dt

            if start_lights_timer >= 1 then
                start_lights_timer = 0
                start_lights_state = start_lights_state + 1
                if useSound then
                    if start_lights_state < 4 then
                        resetSoundsAndPlay("shortBeep")
                    else
                        resetSoundsAndPlay("longBeep")
                    end
                end
                if sendChatMessage and isInitiator then
                    if start_lights_state<4 then
                        ac.sendChatMessage(string.format("%d", start_lights_state))
                    else
                        ac.sendChatMessage("Go!")
                    end
                end
                if start_lights_state <= 4 then
                    lhud.configureLight(start_lights_state, 0, 0.5, true)
                else
                    start_lights_running = false
                    start_lights_state = 0
                    start_lights_timer = 0
                end
            end
        end
        show_start_lights = start_lights_running
        lhud.fadeInLights(dt)
        if start_lights_state == 4 then
            greenLightTimer = greenLightTimer + dt
            if greenLightTimer >= greenLightDuration then
                start_lights_state = 5
                lhud.hideLights() -- scale 1 ?
                start_lights_running = false
                TLightsConnection.Started = false
                tl.removeLightMesh()
            end
        end
        if start_lights_state >= 1 and start_lights_state < 4 then
            TLightsConnection.Light1On = true
            tl.setTrackLightColor(tl.getLightId(1), tl.TrackLightColors.orange)
        else
            TLightsConnection.Light1On = false
            tl.setTrackLightColor(tl.getLightId(1), tl.TrackLightColors.off)
        end
        if start_lights_state >= 2 and start_lights_state < 4 then
            TLightsConnection.Light2On = true
            tl.setTrackLightColor(tl.getLightId(2), tl.TrackLightColors.orange)
        else
            TLightsConnection.Light2On = false
            tl.setTrackLightColor(tl.getLightId(2), tl.TrackLightColors.off)
        end
        if start_lights_state >= 3 and start_lights_state < 4 then
            TLightsConnection.Light3On = true
            tl.setTrackLightColor(tl.getLightId(3), tl.TrackLightColors.orange)
        else
            TLightsConnection.Light3On = false
            tl.setTrackLightColor(tl.getLightId(3), tl.TrackLightColors.off)
        end
        local nbLights = tl.getLightCount()
        if start_lights_state == 4 then
            TLightsConnection.Light4On = true
            if (nbLights<4) then
                tl.setTrackLightColor(1, tl.TrackLightColors.green)
                tl.setTrackLightColor(2, tl.TrackLightColors.green)
                tl.setTrackLightColor(3, tl.TrackLightColors.green)
            else
                tl.setTrackLightColor(tl.getLightId(4), tl.TrackLightColors.green)
            end
        else
            TLightsConnection.Light4On = false
            if (nbLights>3) then
                tl.setTrackLightColor(tl.getLightId(4), tl.TrackLightColors.off)
            end
        end
    end
end

function startLightsManager.draw()
    if show_start_lights and useClassicLightsHUD then
        lhud.draw(orientation, hud_scale, start_lights_state, isYellowBlinking)
    end
end

function startLightsManager.drawMiniHUD()
    lhud.draw("horizontal", 1.02, start_lights_state, isYellowBlinking)
end

function startLightsManager.setScale(scale)
    hud_scale = scale
end

function startLightsManager.getScale()
    return hud_scale
end

function startLightsManager.updateTime(dt)
    currentTime = currentTime + dt
end

function startLightsManager.trackHasLightMesh()
    return tl.trackHasLightMesh()
end

function startLightsManager.trackHasEmbedLightMesh()
    return tl.trackHasEmbedLightMesh()
end

function startLightsManager.getTrackLightPosition()
    return tl.getTrackLightPosition()
end

return startLightsManager
