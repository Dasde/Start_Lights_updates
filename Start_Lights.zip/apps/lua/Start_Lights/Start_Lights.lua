local slMgr = require('start_lights_manager')
local tl = require('track_light')
local update = require('update_utils')
local SERVER_MODE = __dirname == nil
local SLKey = ac.getCarID(0) .. "_startLightsApp"
local SLSharedData = {
  ac.StructItem.key(SLKey .. "_" .. 0),
  serverScriptConnected = ac.StructItem.boolean(),
  appConnected = ac.StructItem.boolean(),
  isAdmin = ac.StructItem.boolean(),
  competitionMode = ac.StructItem.boolean(),
  friendlyCompetitionMode = ac.StructItem.boolean(),
}
local SLightsAppConnection = ac.connect(SLSharedData, false, ac.SharedNamespace.Shared)
if SERVER_MODE then
  SLightsAppConnection.serverScriptConnected = true
else
  SLightsAppConnection.appConnected = true
end

local DEFAULT_TRIGGER_RANGE = 20       -- in meters
local FALSE_START_TRIGGER_RANGE = 30
local DEFAULT_GREEN_LIGHT_DURATION = 2 -- in seconds
local DEFAULT_SCALE = 1                -- default scale for the start light
local DEFAULT_USE_SOUND = true         -- default sound setting
local AppSettings = ac.storage {
  useTriggerRange = true,
  triggerRange = DEFAULT_TRIGGER_RANGE,              -- in meters
  greenLightDuration = DEFAULT_GREEN_LIGHT_DURATION, -- in seconds
  classicLightsScale = DEFAULT_SCALE,                -- default scale for the start light
  useSound = DEFAULT_USE_SOUND,                      -- default sound setting
  classicLightsOrientation = "horizontal",           -- default orientation for the start light
  useClassicLightsHUD = true,
  use3DLights = true,
  lightsModType = tl.LightType.DBZ,
  sendChatMessage = true,
  appPositionX = 50,
  appPositionY = 50
}
local grantedUsers = table.new(5, 5)
local admins = table.new(5, 5)
local grantedUsersChanged ---@type boolean
local competitionModeChanged ---@type boolean
local unSavedGrantedUsers ---@type table
local unSavedCompetitionMode ---@type boolean
local replayDataCount = 0
local replayData ---@type table
local isPaused = false
local lastReplayPos = 0

local function addGrantedUsers(sessionId)
  if not sessionId or sessionId == 0 then return end
  if not table.contains(grantedUsers, sessionId) then
    table.insert(grantedUsers, sessionId)
  end
end

local function addAdmin(sessionId)
  if not table.contains(admins, sessionId) then
    table.insert(admins, sessionId)
  end
end

if ac.isLuaAppRunning("Traffic_Lights") then
  ac.uninstallApp("Traffic_Lights")
end

---can the script run
---@return boolean
local function cannotRun()
  if SERVER_MODE and SLightsAppConnection.appConnected then return true end
  return false
end
if SERVER_MODE then
  local function loadOnlineConfig(online_extras)
    for index, section in online_extras:iterate('TRACK_START_LIGHT_OPERATOR') do
      local adminSteamID = online_extras:get(section, "STEAM_ID", "")
      if ac.getUserSteamID() == adminSteamID then
        addAdmin(ac.getCar(0).sessionID)
        SLightsAppConnection.isAdmin = true
      end
    end
  end
  local online_extras = ac.INIConfig.onlineExtras()
  loadOnlineConfig(online_extras)
  ac.onOnlineWelcome(function(message, config)
    loadOnlineConfig(config)
  end)
  if SLightsAppConnection.appConnected then
    return
  end
end

slMgr.init(AppSettings.classicLightsScale, AppSettings.useSound, AppSettings.classicLightsOrientation,
  AppSettings.lightsModType, AppSettings.sendChatMessage, AppSettings.use3DLights, SERVER_MODE)
if not SERVER_MODE then
  update.init("Start_Lights", "https://raw.githubusercontent.com/Dasde/Start_Lights_updates/refs/heads/main/manifest.ini",
    "https://github.com/Dasde/Start_Lights_updates/raw/refs/heads/main/Start_Lights.zip")
  update.checkForUpdate()
end
-- local triggerMessage = "[Start Lights] Get Ready!"
local triggerStartLightsButton = ac.ControlButton('Start_Lights_TRIGGER_START_LIGHTS',
  { keyboard = { key = (ui.KeyIndex.A) } })

-- local falseStartMessage = "[Start Lights] False start!"
-- local endFalseStartMessage = "[Start Lights] End false start!"
local falseStartButton = ac.ControlButton('Start_Lights_TOGGLE_FALSE_START',
  { keyboard = { key = (ui.KeyIndex.F) } })

local useWhiteList = false
local whiteList = {}
local blackList = {}
local sim = ac.getSim()
local editionMode = false
local BUTTON_SIZE = vec2(150, 50)
local checkAdminPrivilegesTimer = 0

ac.checkAdminPrivileges()
--local EDIT_TEXT_SIZE = vec2(150,100)
local function readList(fileContent, list)
  list = list or {}
  table.clear(list)
  if not fileContent then return end
  for line in fileContent:gmatch("([^\n]*)\n?") do
    if line ~= "" then
      if line:match("^%s*#") then goto continue end -- skip comments
      local trimmed = line:match("^%s*(.-)%s*$")    -- trim whitespace
      if trimmed ~= "" then
        table.insert(list, trimmed)
        -- ac.log("Added to list " .. trimmed)
      end
      ::continue::
    end
  end
end

if not SERVER_MODE then
  if not io.exists(__dirname .. "/whiteList.txt") then
    -- ac.log("Creating default whiteList.txt")
    io.save(__dirname .. "/whiteList.txt", "# Add names to the whitelist, one per line\n# Example: John Doe\n")
  end
  local whiteListFile = io.load(__dirname .. "/whiteList.txt", nil)
  readList(whiteListFile, whiteList)
  if table.count(whiteList) > 0 then
    useWhiteList = true
  else
    useWhiteList = false
  end
  ac.onFileChanged(__dirname .. "/whiteList.txt", function()
    whiteListFile = io.load(__dirname .. "/whiteList.txt", nil)
    readList(whiteListFile, whiteList)
    if #whiteList > 0 then
      useWhiteList = true
    else
      useWhiteList = false
    end
  end)
  if not io.exists(__dirname .. "/blackList.txt") then
    -- ac.log("Creating default blackList.txt")
    io.save(__dirname .. "/blackList.txt", "# Add names to the blackList, one per line\n# Example: John Doe\n")
  end
  local blackListFile = io.load(__dirname .. "/blackList.txt", nil)
  readList(blackListFile, blackList)
  ac.onFileChanged(__dirname .. "/blackList.txt", function()
    blackListFile = io.load(__dirname .. "/blackList.txt", nil)
    readList(blackListFile, blackList)
  end)
end

local function verifySessionID(sessionID)
  return table.contains(admins, sessionID) or table.contains(grantedUsers, sessionID)
end

local function isAdmin()
 return SLightsAppConnection.isAdmin or sim.isAdmin or verifySessionID(ac.getCar(0).sessionID)
end

---Trigger the start lights
---@param _isInitiator boolean
local function triggerStartLights(_isInitiator)
  if slMgr.isYellowBlinking() then return end
  if not SERVER_MODE then
    ac.setAppOpen("Start_Lights")
    ac.setAppWindowVisible("Start_Lights")
    ac.setWindowOpen("main", true)
  else
    ac.setAppWindowVisible("Start_Lights", "main", false)
  end
  slMgr.triggerStartLights(AppSettings.greenLightDuration, _isInitiator)
  if not sim.isReplayActive then
    local position = slMgr.getTrackLightPosition()
    local data = {
      type = "start",
      time = sim.currentSessionTime,
      positionX = position.x,
      positionY = position.y,
      positionZ = position.z,
      rotation = slMgr.getTrackLightsRotation()
    }
    replayDataCount = replayDataCount + 1
    ac.writeReplayBlob("start_lights_" .. replayDataCount, JSON.stringify(data))
    ac.writeReplayBlob("start_lights_count", replayDataCount)
  end
end

local function falseStart(start)
  if start and not SERVER_MODE then
    ac.setAppOpen("Start_Lights")
    ac.setAppWindowVisible("Start_Lights")
    ac.setWindowOpen("main", true)
  end
  slMgr.SetIsYellowBlinking(start)
  slMgr.setStartLightsVisible(start)
  if not sim.isReplayActive then
    local position = slMgr.getTrackLightPosition()
    local data = {
      type = start and "false_start" or "end_false_start",
      time = sim.currentSessionTime,
      positionX = position.x,
      positionY = position.y,
      positionZ = position.z,
      rotation = slMgr.getTrackLightsRotation()
    }
    replayDataCount = replayDataCount + 1
    ac.writeReplayBlob("start_lights_" .. replayDataCount, JSON.stringify(data))
    ac.writeReplayBlob("start_lights_count", replayDataCount)
  end
end

local toggleCompetitionModeEvent = ac.OnlineEvent({
  key = ac.StructItem.key("Start_Lights_toggle_competition_mode_events"),
  competitionMode = ac.StructItem.boolean(),
  grantedUsers = ac.StructItem.array(ac.StructItem.int8(), 16),
  admins = ac.StructItem.array(ac.StructItem.int8(), 16),
  lightPosition = ac.StructItem.vec3(),
  lightRotation = ac.StructItem.float(),
  forceUpdate = ac.StructItem.boolean()
}, function(sender, data)
  if cannotRun() then return end
  if (SLightsAppConnection.competitionMode == data.competitionMode and sender.index == 0) then
    return
  end
  if data.competitionMode ~= SLightsAppConnection.competitionMode then
    if data.competitionMode then
      ac.setMessage("Start Lights", "Competition Mode activated")
      SLightsAppConnection.friendlyCompetitionMode = false
    else
      ac.setMessage("Start Lights", "Competition Mode deactivated")
    end
  end
  SLightsAppConnection.competitionMode = data.competitionMode
  if (not slMgr.trackHasLightMesh() or data.forceUpdate) and data.lightPosition and data.lightPosition ~= vec3() then
    slMgr.setAndSaveTrackLights(data.lightPosition, data.lightRotation)
  end
  -- table.clear(grantedUsers)
  -- addGrantedUsers(sender.sessionID)
  for i = 0, 15, 1 do
    addGrantedUsers(data.grantedUsers[i])
  end
  for i = 0, 15, 1 do
    addAdmin(data.admins[i])
  end
end, ac.SharedNamespace.Shared, false, { processPostponed = true })

local updateGrantedUsers = ac.OnlineEvent({
  key = ac.StructItem.key("Start_Lights_update_granted_users_events"),
  addedGrantedUsers = ac.StructItem.array(ac.StructItem.int8(), 16),
  removedGrantedUsers = ac.StructItem.array(ac.StructItem.int8(), 16),
  admins = ac.StructItem.array(ac.StructItem.int8(), 16),
}, function(sender, data)
  if cannotRun() then return end
  if (sender.index == 0) then
    return
  end
  addGrantedUsers(sender.sessionID)
  for i = 0, 15, 1 do
    addGrantedUsers(data.addedGrantedUsers[i])
  end
  for i = 0, 15, 1 do
    if table.contains(grantedUsers, data.removedGrantedUsers[i]) then
      table.removeItem(grantedUsers, data.removedGrantedUsers[i])
    end
  end
  for i = 0, 15, 1 do
    addAdmin(data.admins[i])
  end
end, ac.SharedNamespace.Shared)

if SLightsAppConnection.isAdmin then
  addAdmin(ac.getCar(0).sessionID)
  updateGrantedUsers({ admins = { ac.getCar(0).sessionID } }, true)
end

local startLightsEvent = ac.OnlineEvent({
  key = ac.StructItem.key("Start_Lights_trigger_events"),
  start = ac.StructItem.boolean(),
  falseStart = ac.StructItem.boolean(),
  endFalseStart = ac.StructItem.boolean(),
  lightPosition = ac.StructItem.vec3(),
  lightRotation = ac.StructItem.float(),
  friendlyCompetitionMode = ac.StructItem.boolean(),
}, function(sender, data)
  if cannotRun() then return end
  if not SERVER_MODE and not SLightsAppConnection.competitionMode and sender.index > 0 then
    local senderName = ac.getDriverName(sender.index)
    if useWhiteList then
      local isInWhiteList = false
      for _, name in ipairs(whiteList) do
        ---@diagnostic disable-next-line: need-check-nil
        if senderName:lower() == name:lower() then
          isInWhiteList = true
          break
        end
      end
      if not isInWhiteList then
        return
      end
    else
      for _, name in ipairs(blackList) do
        ---@diagnostic disable-next-line: need-check-nil
        if senderName:lower() == name:lower() then
          return
        end
      end
    end
  end
  if data.endFalseStart then
    falseStart(false)
    return
  end
  if data.start or data.falseStart then
    if (SLightsAppConnection.competitionMode or SLightsAppConnection.friendlyCompetitionMode) and not slMgr.trackHasEmbedLightMesh() then
      if data.lightPosition ~= slMgr.getTrackLightPosition() or data.lightRotation ~= slMgr.getTrackLightsRotation() then
        slMgr.setAndSaveTrackLights(data.lightPosition, data.lightRotation)
      end
    end
    if not slMgr.trackHasLightMesh() and data.lightPosition and data.lightPosition ~= vec3() then
      slMgr.setAndSaveTrackLights(data.lightPosition, data.lightRotation)
    end

    if sender.index > 0 then
      local senderCarPostion = sender.position;
      local ourCarPosition = ac.getCar(0).position;
      local range = data.falseStart and FALSE_START_TRIGGER_RANGE or AppSettings.triggerRange
      local distance
      local refPoint
      if not (SLightsAppConnection.friendlyCompetitionMode or SLightsAppConnection.competitionMode) then
        refPoint = slMgr.trackHasLightMesh() and slMgr.getTrackLightPosition() or ourCarPosition
        distance = senderCarPostion:distance(refPoint)
        if distance > range then
          return
        end
      end
      if AppSettings.useTriggerRange then
        refPoint = slMgr.trackHasLightMesh() and slMgr.getTrackLightPosition() or senderCarPostion
        distance = ourCarPosition:distance(refPoint)
        if (distance > range) then
          return
        end
      end
    end
    if data.falseStart then
      falseStart(true)
    else
      triggerStartLights(sender.index == 0)
    end
  end
end, ac.SharedNamespace.Shared)

local requestLightsData = ac.OnlineEvent({
  key = ac.StructItem.key("Start_Lights_request_data_events"),
}, function(sender, data)
  if cannotRun() then return end
  if ((#admins > 0 or #grantedUsers > 0) and not (isAdmin())) or not slMgr.trackHasLightMesh() then
    return
  end
  toggleCompetitionModeEvent(
    {
      competitionMode = SLightsAppConnection.competitionMode,
      grantedUsers = grantedUsers,
      admins = admins,
      lightPosition = slMgr.getTrackLightPosition(),
      lightRotation = slMgr.getTrackLightsRotation()
    }, false, sender.sessionID)
end, ac.SharedNamespace.Shared)
requestLightsData({})

local function onStartLights()
  if (sim.isOnlineRace) then
    if SLightsAppConnection.competitionMode then
      if (isAdmin()) then
        if slMgr.trackHasLightMesh() then
          startLightsEvent { start = true, falseStart = false, endFalseStart = false, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation() }
        else
          ac.setMessage("Start Lights", "No track light configured yet.", 'illegal')
        end
      else
        ac.setMessage("Start Lights", "Competition mode activated, only admins can operate the lights.", 'illegal')
      end
    elseif SLightsAppConnection.friendlyCompetitionMode then
      if slMgr.trackHasLightMesh() then
        startLightsEvent { start = true, falseStart = false, endFalseStart = false, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation(), friendlyCompetitionMode = true }
      else
        ac.setMessage("Start Lights", "No track light configured yet.", 'illegal')
      end
    elseif slMgr.trackHasLightMesh() then
      if ac.getCar(0).position:distance(slMgr.getTrackLightPosition()) <= AppSettings.triggerRange then
        startLightsEvent { start = true, falseStart = false, endFalseStart = false, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation() }
      else
        ac.setMessage("Start Lights", "You are too far.", 'illegal')
      end
    else
      startLightsEvent { start = true, falseStart = false, endFalseStart = false, lightPosition = nil, lightRotation = 0 }
    end
  else
    --ac.log("Triggering Start lights in offline mode")
    triggerStartLights(true)
  end
end

local function onFalseStart()
  if (not slMgr.isYellowBlinking()) then
    if (sim.isOnlineRace) then
      if SLightsAppConnection.competitionMode then
        if (isAdmin()) then
          startLightsEvent { start = false, falseStart = true, endFalseStart = false, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation() }
        else
          ac.setMessage("Start Lights", "Competition mode activated, only admins can operate the lights.", 'illegal')
        end
      elseif SLightsAppConnection.friendlyCompetitionMode then
        if slMgr.trackHasLightMesh() then
          startLightsEvent { start = false, falseStart = true, endFalseStart = false, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation(), friendlyCompetitionMode = true }
        else
          ac.setMessage("Start Lights", "No track light configured yet.", 'illegal')
        end
      elseif slMgr.trackHasLightMesh() then
        if ac.getCar(0).position:distance(slMgr.getTrackLightPosition()) <= FALSE_START_TRIGGER_RANGE then
          startLightsEvent { start = false, falseStart = true, endFalseStart = false, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation() }
        else
          ac.setMessage("Start Lights", "You are too far.", 'illegal')
        end
      else
        startLightsEvent { start = false, falseStart = true, endFalseStart = false, lightPosition = nil, lightRotation = 0 }
      end
    else
      falseStart(false)
    end
  else
    if (sim.isOnlineRace) then
      if SLightsAppConnection.competitionMode then
        if (isAdmin()) then
          startLightsEvent { start = false, falseStart = false, endFalseStart = true, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation() }
        else
          ac.setMessage("Start Lights", "Competition mode activated, only admins can operate the lights.", 'illegal')
        end
      elseif SLightsAppConnection.friendlyCompetitionMode then
        startLightsEvent { start = false, falseStart = false, endFalseStart = true, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation(), friendlyCompetitionMode = true }
      else
        startLightsEvent { start = false, falseStart = false, endFalseStart = true, lightPosition = nil, lightRotation = 0 }
      end
    else
      falseStart(false)
    end
  end
end

local function reloadReplayData()
  replayData = {}
  ---@diagnostic disable-next-line: cast-local-type
  replayDataCount = tonumber(ac.readReplayBlob("start_lights_count"))
  if replayDataCount and replayDataCount > 0 then
    for i = 1, replayDataCount + 1, 1 do
      local jdata = ac.readReplayBlob("start_lights_" .. i)
      ---@diagnostic disable-next-line: param-type-mismatch
      local data = JSON.parse(jdata)
      table.insert(replayData, data)
    end
  end
end

if sim.isReplayActive then
  reloadReplayData()
end

ac.onClientConnected(function(connectedCarIndex, connectedSessionID)
  if cannotRun() then return end
  setTimeout(function()
    if (isAdmin()) then
      addAdmin(ac.getCar(0).sessionID)
      local adminsStruct = ac.StructItem.array(ac.StructItem.int8(), 16)
      for i = 1, #admins, 1 do
        adminsStruct[i-1] = admins[i]
      end
      toggleCompetitionModeEvent(
      { competitionMode = SLightsAppConnection.competitionMode, grantedUsers = grantedUsers, admins = adminsStruct, lightPosition =
      slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation(), forceUpdate = true }, false,
        connectedSessionID)
    end
  end, 5)
end)

ac.onClientDisconnected(function(connectedCarIndex, connectedSessionID)
  if cannotRun() then return end
  if not verifySessionID(connectedSessionID) then return end
  if table.contains(grantedUsers, connectedSessionID) then
    table.removeItem(grantedUsers, connectedSessionID)
    if isAdmin() then
      updateGrantedUsers({ removedGrantedUsers = { connectedSessionID } }, true)
    end
  end
  if table.contains(admins, connectedSessionID) then
    table.removeItem(admins, connectedSessionID)
    if isAdmin then
      updateGrantedUsers({ admins = admins }, true)
    end
  end
  if #admins == 0 and #grantedUsers == 0 then
    SLightsAppConnection.competitionMode = false
  end
end)

local descFriendlyComp =
"This mode is for friendly battles. \nEvery driver has to activate it to participate.\nWith this mode every driver can activate the start lights without range restrictions.\nThe lights will be only activated for those with that mode activated"
local maxDescFriendlyCompWidth = 0
local maxDescFriendlyCompWidthMiniHUD = 0
local miniHUDrunning
function script.windowCompetitionMode(dt)
  miniHUDrunning = true
  if not (sim.isAdmin or verifySessionID(ac.getCar(0).sessionID)) then
    if SLightsAppConnection.isAdmin then
      addAdmin(ac.getCar(0).sessionID)
      updateGrantedUsers({ admins = { ac.getCar(0).sessionID } }, false)
    end
    ui.setCursor(10)
    ui.text("You are not a granted operator on this server.")
  end
  local bgSize = (slMgr.isStartLightsActive() or slMgr.isYellowBlinking()) and ui.windowSize():clone():add(vec2(0, -70)) or
      ui.windowSize()
  --ui.drawRectFilled(vec2(0, 0), bgSize, rgbm(0, 0, 0, 0.15))
  ui.drawRect(vec2(0, 0), bgSize, rgbm(0.6, 0.6, 0.6, 0.15))
  ui.newLine(8)
  ui.pushFont(ui.Font.Title)
  ui.setNextItemWidth(450)
  ui.setCursorX(20)
  ui.text("Start Lights - Competition Mode    ")
  ui.setCursorX(20)
  if SLightsAppConnection.competitionMode then
    ui.textColored("Activated", rgbm.colors.red)
  else
    ui.textColored("Not Activated", rgbm.colors.gray)
  end
  ui.popFont()
  ui.newLine(2)
  ui.setCursorX(20)
  script.windowContentCompetitionMode(dt)
  if slMgr.isStartLightsActive() or slMgr.isYellowBlinking() then
    local childHeight = (ui.windowWidth() / 300) * 80
    ui.childWindow("mini-hud", vec2(ui.windowWidth(), childHeight), function()
      slMgr.drawMiniHUD()
    end)
  end
end

function script.windowContentCompetitionMode(dt)
  local buttonSize = vec2(120, 50)
  if isAdmin() then
    local windowCursor = 20
    if slMgr.trackHasLightMesh() then
      if ui.button("Force update start light position") then
        toggleCompetitionModeEvent { competitionMode = SLightsAppConnection.competitionMode, grantedUsers = grantedUsers, admins = admins, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation(), forceUpdate = true }
      end
    end
    if not competitionModeChanged then
      unSavedCompetitionMode = SLightsAppConnection.competitionMode
    end
    ui.setCursorX(windowCursor)
    if ui.checkbox("Toggle Competition Mode", unSavedCompetitionMode) then
      unSavedCompetitionMode = not unSavedCompetitionMode
      competitionModeChanged = true
    end
    if (sim.isAdmin or SLightsAppConnection.isAdmin) then
      ui.setCursorX(windowCursor)
      ui.text("Lights operators :")
      if not grantedUsersChanged then
        unSavedGrantedUsers = table.clone(grantedUsers)
      end
      for i, car in ac.iterateCars() do
        local checked = car.index == 0 or table.contains(unSavedGrantedUsers, car.sessionID) or
        table.contains(admins, car.sessionID)
        ui.setCursorX(windowCursor)
        if table.contains(admins, car.sessionID) then
          ui.pushDisabled()
        end
        if car.isConnected then
          ---@diagnostic disable-next-line: param-type-mismatch
          if ui.checkbox(ac.getDriverName(car.index), checked) then
            checked = not checked
            grantedUsersChanged = true
            if checked then
              table.insert(unSavedGrantedUsers, car.sessionID)
            else
              table.removeItem(unSavedGrantedUsers, car.sessionID)
            end
          end
        end
        if table.contains(admins, car.sessionID) then
          ui.popDisabled()
        end
      end
      grantedUsersChanged = not table.same(grantedUsers, unSavedGrantedUsers)
    else
      grantedUsersChanged = false
      unSavedGrantedUsers = table.clone(grantedUsers)
    end
    ui.newLine(15)
    competitionModeChanged = (SLightsAppConnection.competitionMode ~= unSavedCompetitionMode)
    if (grantedUsersChanged or competitionModeChanged) then
      ui.setCursorX(30)
      if ui.button("Validate", buttonSize) then
        local addedGrantedUsers, removedGrantedUsers = {}, {}
        for index, user in ipairs(unSavedGrantedUsers) do
          if not table.contains(grantedUsers, user) then
            table.insert(addedGrantedUsers, user)
          end
        end
        for index, user in ipairs(grantedUsers) do
          if not table.contains(unSavedGrantedUsers, user) then
            table.insert(removedGrantedUsers, user)
          end
        end
        grantedUsers = table.clone(unSavedGrantedUsers)
        if competitionModeChanged then
          --competitionMode = unSavedCompetitionMode
          toggleCompetitionModeEvent { competitionMode = unSavedCompetitionMode, grantedUsers = grantedUsers, admins = admins, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation() }
          competitionModeChanged = false
          grantedUsersChanged = false
        else
          updateGrantedUsers { addedGrantedUsers = addedGrantedUsers, removedGrantedUsers = removedGrantedUsers }
          grantedUsersChanged = false
        end
      end
      ui.sameLine(0, ui.windowWidth() - 300)
      if ui.button("Cancel", buttonSize) then
        competitionModeChanged = false
        grantedUsersChanged = false
      end
      ui.newLine(10)
    end
  end
  if not SLightsAppConnection.competitionMode then
    ui.setNextTextBold()
    ui.setCursorX(10)
    ui.text("Friendly Competition Mode")
    ui.setCursorX(10)
    local descFriendlyCompWidth
    if miniHUDrunning then
      if maxDescFriendlyCompWidthMiniHUD == 0 then
        maxDescFriendlyCompWidthMiniHUD = ui.measureText(descFriendlyComp).x + 10
      end
      descFriendlyCompWidth = maxDescFriendlyCompWidthMiniHUD
    else
      if maxDescFriendlyCompWidth == 0 then
        maxDescFriendlyCompWidth = ui.measureText(descFriendlyComp).x
      end
      descFriendlyCompWidth = maxDescFriendlyCompWidth
    end
    ui.textAligned(descFriendlyComp, 0, vec2(descFriendlyCompWidth, 100))
    ui.setCursorX(10)
    if ui.checkbox("Toggle Friendly Competition Mode", SLightsAppConnection.friendlyCompetitionMode) then
      SLightsAppConnection.friendlyCompetitionMode = not SLightsAppConnection.friendlyCompetitionMode
    end
    ui.newLine()
  end
  if (SLightsAppConnection.competitionMode and (isAdmin())) or SLightsAppConnection.friendlyCompetitionMode then
    ui.setCursorX(30)
    if ui.button("Trigger Start!", buttonSize) then
      onStartLights()
    end
    ui.sameLine(0, ui.windowWidth() - 300)
    if ui.button("False Start!", buttonSize) then
      onFalseStart()
    end
    ui.newLine(10)
  end
end

function script.windowSettings(dt)
  miniHUDrunning = false
  if SLightsAppConnection.competitionMode then
    ui.pushFont(ui.Font.Huge)
    ui.setNextTextBold()
    ui.textColored("Competition Mode Activated!", rgbm.colors.red)
    ui.popFont()
  end
  ui.pushFont(ui.Font.Title)
  ui.tabBar("settings", function()
    ui.tabItem("General", function()
      local scaleChanged
      ui.text("Orientation :")
      if ui.radioButton("Vertical", AppSettings.classicLightsOrientation == "vertical") then
        AppSettings.classicLightsOrientation = "vertical"
        slMgr.setOrientation(AppSettings.classicLightsOrientation)
        script.resizeWindowMain()
      end
      if ui.radioButton("Horizontal", AppSettings.classicLightsOrientation == "horizontal") then
        AppSettings.classicLightsOrientation = "horizontal"
        slMgr.setOrientation(AppSettings.classicLightsOrientation)
        script.resizeWindowMain()
      end
      if ui.checkbox("Use Trigger Range", AppSettings.useTriggerRange) then
        AppSettings.useTriggerRange = not AppSettings.useTriggerRange
      end
      if AppSettings.useTriggerRange then
        AppSettings.triggerRange = ui.slider("Trigger Range (m)", AppSettings.triggerRange, 10, 100)
      else
        AppSettings.triggerRange = DEFAULT_TRIGGER_RANGE -- reset to default if not using range
      end
      AppSettings.greenLightDuration = ui.slider("Green Light Duration (s)", AppSettings.greenLightDuration, 1, 10)
      AppSettings.classicLightsScale, scaleChanged = ui.slider("Start Light Scale", AppSettings.classicLightsScale, 0.1,
        3)
      if scaleChanged then
        slMgr.setScale(AppSettings.classicLightsScale)
        script.resizeWindowMain()
      end
      if ui.checkbox("Use Sound", AppSettings.useSound) then
        AppSettings.useSound = not AppSettings.useSound
        slMgr.setUseSound(AppSettings.useSound)
      end
      if ui.checkbox("Display classic lights HUD", AppSettings.useClassicLightsHUD) then
        AppSettings.useClassicLightsHUD = not AppSettings.useClassicLightsHUD
        slMgr.setUseClassicLightsHUD(AppSettings.useClassicLightsHUD)
      end
      if ui.checkbox("Send chat message to non user of the app (Get Ready,1,2,3,Go!)", AppSettings.sendChatMessage) then
        AppSettings.sendChatMessage = not AppSettings.sendChatMessage
        slMgr.setSendChatMessage(AppSettings.sendChatMessage)
      end
      if ui.checkbox("Display 3D Lights in front of car. (if there are no lights on track already)", AppSettings.use3DLights) then
        AppSettings.use3DLights = not AppSettings.use3DLights
        slMgr.setUse3DLights(AppSettings.use3DLights)
      end
      if AppSettings.use3DLights and io.fileExists(ac.getFolder(ac.FolderID.ContentCars) .. "/vdm_lights/vdm_lights.kn5") then
        ui.text("Choose your start lights :")
        local selectedDBZMod = (AppSettings.lightsModType == tl.LightType.DBZ)
        if ui.radioButton("DBZ", selectedDBZMod) then
          AppSettings.lightsModType = not selectedDBZMod and tl.LightType.DBZ or tl.LightType.VDM
          slMgr.set3DModType(AppSettings.lightsModType)
          slMgr.reloadTrackLights(true)
        end
        local selectedVDMMod = (AppSettings.lightsModType == tl.LightType.VDM)
        if ui.radioButton("VDM", selectedVDMMod) then
          AppSettings.lightsModType = not selectedVDMMod and tl.LightType.VDM or tl.LightType.DBZ
          slMgr.set3DModType(AppSettings.lightsModType)
          slMgr.reloadTrackLights(true)
        end
      end
      ui.separator()
      ui.setNextTextBold()
      ui.text("How to trigger the start lights")
      if SLightsAppConnection.competitionMode and not (isAdmin()) then
        ui.textColored("Not available in Competition Mode", rgbm.colors.red)
      end
      local configuredControl = triggerStartLightsButton:boundTo()
      if not configuredControl then
        ui.text(
          "The control to start the lights isn't configured yet.")
      else
        ui.text("Press " .. configuredControl .. " to start the lights")
      end
      triggerStartLightsButton:control(BUTTON_SIZE, ui.ControlButtonControlFlags.IgnoreConflicts)
      ui.setNextTextBold()
      ui.text("How to trigger false start")
      configuredControl = falseStartButton:boundTo()
      if not configuredControl then
        ui.text(
          "The control to trigger a false start isn't configured yet.")
      else
        ui.text("Press " .. configuredControl .. " to trigger a false start")
      end
      falseStartButton:control(BUTTON_SIZE, ui.ControlButtonControlFlags.IgnoreConflicts)
      if not SERVER_MODE and ac.isLuaAppRunning("ext_controls") then
        ui.separator()
        ui.text("You can also change the controls with the Extended Controls app (Apps/Start Lights)")
        if ui.button("Open Extended Controls") then
          ac.setAppOpen("ext_controls")
          ac.setAppWindowVisible("ext_controls")
        end
      end
      if not SERVER_MODE then
        ui.separator()
        ui.setNextTextBold()
        ui.text("Whitelist and Blacklist Settings")
        if useWhiteList then
          ui.text("Whitelist is enabled. Only players in the whitelist can operate the start lights.")
        else
          ui.text("Whitelist is disabled. All players can operate the start lights.")
        end
        if #whiteList > 0 then
          ui.text("Whitelist: " .. table.concat(whiteList, ", "))
        else
          ui.text("Whitelist is empty.")
        end
        if #blackList > 0 then
          ui.text("Blacklist: " .. table.concat(blackList, ", "))
        else
          ui.text("Blacklist is empty.")
        end
        if ui.button("Open Whitelist") then
          os.openInExplorer(__dirname .. "/whiteList.txt")
        end
        ui.sameLine(170)
        if ui.button("Open Blacklist") then
          os.openInExplorer(__dirname .. "/blackList.txt")
        end
      end
      ui.separator()
      ui.newLine(20)
      if not SERVER_MODE then
        if ui.button("Restart app...", BUTTON_SIZE) then
          ac.restartApp()
        end
        ui.newLine()
      end
      ui.newLine()
    end)
    ui.tabItem("Track light editor", function()
      if slMgr.trackHasEmbedLightMesh() then
        ui.text("This track has its own start lights already. It's not editable.")
        ui.newLine()
      elseif slMgr.trackHasLightMesh() then
        ui.text(string.format("A track start light is already on track at position\n%s.", slMgr.getTrackLightPosition()))
        ui.separator()
        ui.newLine(15)
      else
        ui.newLine(5)
        if not SERVER_MODE then
          ui.text(
            "If you have a track_lights.ini file for the track paste it in the track layout folder and restart the app.")
          ui.separator()
          ui.newLine()
          if ui.button("Restart app...", BUTTON_SIZE) then
            ac.restartApp()
          end
        end
        ui.sameLine()
      end
      --ui.setCursorX(ui.getCursorX() +
      -- ((ui.windowWidth() - ui.getCursorX() - 300 + (editionMode and 0 or -BUTTON_SIZE.x - 40)) / 2))
      if not SERVER_MODE then
        if not slMgr.trackHasEmbedLightMesh() then
          if ui.button("Open track folder...", vec2(300, BUTTON_SIZE.y)) then
            local trackIniFilename = ac.getFolder(ac.FolderID.CurrentTrackLayoutUI) .. "/" .. "track_lights.ini"
            if io.exists(trackIniFilename) then
              os.showInExplorer(trackIniFilename)
            else
              os.openInExplorer(ac.getFolder(ac.FolderID.CurrentTrackLayoutUI))
            end
          end
          ui.sameLine()
        end
      end
      if slMgr.trackHasLightMesh() and not slMgr.trackHasEmbedLightMesh() then
        if ui.button("Remove", BUTTON_SIZE) then
          editionMode = false
          slMgr.trackLightEdition(editionMode)
          slMgr.clearSavedLights()
        end
      end
      if editionMode then
        ui.setMouseCursor(ui.MouseCursor.ResizeAll)
        ui.separator()
        ui.newLine(5)
        ui.text(
          "Just double click on the map where you want to place the start lights.\nClick the save button when you are done.")
        ui.newLine(15)
        local rot = refnumber(slMgr.getTrackLightsRotation())
        ui.setNextItemWidth(350)
        ui.setCursorX((ui.windowWidth() - 350) / 2)
        if ui.slider("'##rotationSliderID'", rot, 0, 360, 'Rotation: %.1f') then
          slMgr.rotateTrackLights(rot.value)
        end
        ui.newLine(5)
        ui.setCursorX((ui.windowWidth() - (2 * BUTTON_SIZE.x) - 10) / 2)
        if ui.button("Save", BUTTON_SIZE) then
          editionMode = false
          slMgr.trackLightEdition(editionMode)
          slMgr.saveTrackLights()
        end
        ui.sameLine()
        if ui.button("Cancel", BUTTON_SIZE) then
          editionMode = false
          slMgr.trackLightEdition(editionMode)
          slMgr.reloadTrackLights(false)
        end
      else
        ui.setMouseCursor(ui.MouseCursor.Arrow)
        if not slMgr.trackHasEmbedLightMesh() then
          ui.sameLine()
          --  ui.setCursorX(ui.getCursorX() + (ui.windowWidth() - ui.getCursorX() - BUTTON_SIZE.x) / 2)
          if ui.button(slMgr.trackHasLightMesh() and "Edit Light..." or "Create Light...", BUTTON_SIZE) then
            editionMode = true
            slMgr.trackLightEdition(editionMode)
          end
        end
        if slMgr.trackHasLightMesh() then
          ui.sameLine()
          if ui.button("Copy data", BUTTON_SIZE) then
            if ac.setClipboardText(slMgr.getTrackLightConfig()) then
              ui.toast(ui.Icons.Clipboard, "Data copied to clipboard")
            end
          end
        end
      end
      ui.newLine()
    end)

    if SLightsAppConnection.competitionMode and not (isAdmin()) then
      ui.tabItem("Competition Mode", function()
        ui.pushFont(ui.Font.Huge)
        ui.setNextTextBold()
        ui.textColored("Competition Mode Activated!", rgbm.colors.red)
        ui.popFont()
        ui.text("Only admins can operate the Track Lights")
      end)
    else
      ui.tabItem("Competition Mode", function()
        script.windowContentCompetitionMode(dt)
        ui.newLine()
      end)
    end

    if not SERVER_MODE then
      ui.tabItem("Updates", function()
        update.drawUI()
      end)
    else
      ui.tabItem("Download the App!", function()
        ui.bulletText("Start Lights on every servers")
        ui.bulletText("Ability to operate the semaphore from the pit")
        ui.bulletText("Ability to save and reload your semaphore position for a track")
        ui.text("Download the App :")
        ui.sameLine()
        if ui.textHyperlink("https://vosan.co/app-tools/start-lights") then
          os.openURL("https://vosan.co/app-tools/start-lights")
        end
        ui.newLine()
      end)
    end
    ui.tabItem("About", function()
      ui.drawCircleFilled(vec2(ui.getCursorX() + ui.measureText("The Start Lights ").x + 12, ui.getCursorY() + 12), 12,
        rgbm.colors.white)
      ui.text("The Start Lights " .. string.codePointToUTF8(8482) .. " system is developped by")
      ui.sameLine()
      if ui.textHyperlink("DaZD") then
        os.openURL("https://linktr.ee/dazdsim")
      end
      ui.text("Feel free to contact me if you need my assistance to set up a competition or a server or any feedback.")
      ui.text("My Discord is in the linktree linked above.")
      ui.newLine()
      ui.text("With ")
      ui.sameLine()
      if ui.textHyperlink("CDT - Ömer Bağdatlı") then
        os.openURL("https://www.instagram.com/rahvanr1/")
      end
      ui.sameLine()
      ui.text(" we are building a list of semaphore position by track.")
      ui.text("That list is already used by the App, no need to add a Start Lights semaphore on those tracks.")
      ui.text("Contact us if you want to contribute or if you want your track to be added.")
      ui.newLine()
      ui.setNextTextBold()
      ui.text("How To")
      ui.newLine()
      ui.setNextTextBold()
      ui.bulletText("To add the Start Lights script to your server add this to your configuration :")
      local addScriptSnippet =
      "[SCRIPT_0]\nSCRIPT = 'https://github.com/Dasde/Start_Lights_updates/raw/refs/heads/main/start_light_server_script.lua'"
      ui.text(addScriptSnippet)
      if ui.button("Copy to clipboard") then
        if ac.setClipboardText(addScriptSnippet) then
          ui.toast(ui.Icons.Clipboard, "Data copied to clipboard")
        end
      end
      ui.newLine()
      ui.setNextTextBold()
      ui.bulletText("Operators can be added like this :")
      local addOperatorSnippet = "[TRACK_START_LIGHT_OPERATOR_0]\nSTEAM_ID=Steam id of the operator"
      ui.text(addOperatorSnippet)
      if ui.button("Copy to clipboard###2") then
        if ac.setClipboardText(addOperatorSnippet) then
          ui.toast(ui.Icons.Clipboard, "Data copied to clipboard")
        end
      end
      ui.newLine()
      ui.setNextTextBold()
      ui.bulletText("Set custom semaphore position like this :")
      ui.text('Go to the track, position the semaphore then click "Copy data" in the "Track light editor" tab.')
      ui.text("Then paste the text in your configuration file and ajust the number after the _ (increment)")
      ui.text("It should look like this :")
      ui.text(
        "[TRACK_START_LIGHT_0]\nTRACK=cfd_val_de_vienne_2022\nX=495.0426940918\nY=1.5083720684052\nZ=69.54564666748\nROT=344.89999389648\n")
      ui.newLine()
      -- ui.text("Help us add more tracks position to the shared repository :")
      -- if ui.textHyperlink("Submit a PR at Start_Lights_tracks on github") then
      --     os.openURL("https://github.com/Dasde/Start_Lights_tracks")
      -- end
      ui.separator()
      ui.text("You can support the project here :")
      ui.sameLine()
      if ui.textHyperlink("paypal.me/DaZDSim") then
        os.openURL("https://www.paypal.com/paypalme/DaZDSim")
      end
      ui.newLine()
    end)
  end)
  ui.popFont()
end

function script.resizeWindowMain()
  if SERVER_MODE then return end
  local size = AppSettings.classicLightsOrientation == "vertical" and
      vec2(math.max(80 * AppSettings.classicLightsScale, 200), math.max(300 * AppSettings.classicLightsScale, 50)) or
      vec2(math.max(300 * AppSettings.classicLightsScale, 200), math.max(80 * AppSettings.classicLightsScale, 50))
  ac.setWindowSizeConstraints("main", size, size)
end

function script.windowMain(dt)
  miniHUDrunning = false
  if (slMgr.isStartLightsActive() or slMgr.isYellowBlinking()) then
    script.drawUI(dt)
  else
    if ui.windowHovered(bit.bor(ui.HoveredFlags.RootAndChildWindows, ui.HoveredFlags.AllowWhenBlockedByActiveItem)) then
      slMgr.setStartLightsVisible(true)
      script.drawUI(dt)
      if not SERVER_MODE and not ac.isWindowOpen("settings") then
        ui.offsetCursorY((ui.windowHeight() - 50) / 2)
        ui.offsetCursorX((ui.windowWidth() - 200) / 2)
        if ui.button("Show Start Lights settings...", vec2(200, 50)) then
          script.openWindowSettings(dt)
        end
      end
    else
      slMgr.setStartLightsVisible(false)
    end
  end
end

local settingsOpened = false
local windowPosition = vec2(AppSettings.appPositionX, AppSettings.appPositionY)
local windowSize = vec2(500, 500)
local settingsSize = vec2(500, 500)
local isMouseDragging
function script.drawUI(dt)
  if cannotRun() then return end
  if SERVER_MODE then
    ui.restoreCursor()
    if isMouseDragging then
      if not ui.mouseDown(ui.MouseButton.Left) then
        isMouseDragging = false
        ui.resetMouseDragDelta(ui.MouseButton.Left)
      else
        local delta = ui.mouseDragDelta(ui.MouseButton.Left)
        if delta ~= vec2() then
          windowPosition:add(ui.mouseDragDelta(ui.MouseButton.Left))
          AppSettings.appPositionX = windowPosition.x
          AppSettings.appPositionY = windowPosition.y
          ui.resetMouseDragDelta(ui.MouseButton.Left)
          isMouseDragging = true
        end
      end
    end
    local hudSize = AppSettings.classicLightsOrientation == "vertical" and
        vec2(80 * AppSettings.classicLightsScale,
          300 * AppSettings.classicLightsScale)
        or
        vec2(300 * AppSettings.classicLightsScale,
          80 * AppSettings.classicLightsScale)
    ui.transparentWindow("main", windowPosition, windowSize, false, true, function()
      if settingsOpened then
        ui.drawRectFilled(vec2(0, 0), settingsSize, rgbm(0.4, 0.4, 0.4, 0.5), 10, ui.CornerFlags.All)
        if ui.iconButton(ui.Icons.TrafficLight, vec2(32, 32)) then
          settingsOpened = not settingsOpened
        end
        if ui.itemHovered(ui.HoveredFlags.None) then
          ui.tooltip(function()
            ui.text("Close Settings")
          end)
        end
        script.windowSettings(dt)
      else
        if ui.iconButton(ui.Icons.TrafficLight, vec2(32, 32)) then
          settingsOpened = not settingsOpened
        end
        if ui.itemHovered(ui.HoveredFlags.None) then
          ui.tooltip(function()
            ui.text("Open Settings")
          end)
        end
      end
      if (slMgr.isStartLightsActive() or slMgr.isYellowBlinking()) then
        slMgr.draw()
      else
        slMgr.setStartLightsVisible(false)
        if ui.windowHovered() then -- bit.bor(ui.HoveredFlags.RootAndChildWindows, ui.HoveredFlags.AllowWhenBlockedByActiveItem)
          ui.setMouseCursor(ui.MouseCursor.Hand)
          if not isMouseDragging and ui.mouseDown(ui.MouseButton.Left) then
            local delta = ui.mouseDragDelta(ui.MouseButton.Left)
            if delta ~= vec2() then
              windowPosition:add(ui.mouseDragDelta(ui.MouseButton.Left))
              AppSettings.appPositionX = windowPosition.x
              AppSettings.appPositionY = windowPosition.y
              ui.resetMouseDragDelta(ui.MouseButton.Left)
              isMouseDragging = true
            end
          end
        end
      end
      settingsSize = vec2(ui.getMaxCursorX() + 20, ui.getMaxCursorY())
      windowSize = vec2(math.max(hudSize.x, ui.getMaxCursorX() + 20), math.max(hudSize.y, ui.getMaxCursorY()))
    end)
  else
    slMgr.draw()
  end
end

ac.onSessionStart(function(sessionIndex, restarted)
  if cannotRun() then return end
  if restarted then
    replayDataCount = 0
    ac.writeReplayBlob("start_lights_count", 0)
    reloadReplayData()
  end
end)

ac.onChatMessage(function(message, senderCarIndex, senderSessionID)
  if cannotRun() then return end

  if message:startsWith("[StartLights]") then
    return true
    ---@diagnostic disable-next-line: missing-return
  end
end)

function script.update(dt)
  if SLightsAppConnection.appConnected and SERVER_MODE then
    if slMgr.trackHasLightMesh() then
      slMgr.disposeLightMesh()
    end
  end
  isPaused = ac.getGameDeltaT() == 0
  if sim.isReplayActive then
    reloadReplayData()
    local currentTime
    local replayPos = sim.replayFrames - sim.replayCurrentFrame
    if replayPos > lastReplayPos + 5 or replayPos < lastReplayPos - 5 then
      -- seeking in the replay timeline
      slMgr.stopStartLights()
    end
    lastReplayPos = replayPos
    if sim.isReplayOnlyMode then
      currentTime = sim.currentSessionTime
    else
      local minTimeAvailable = sim.currentSessionTime - (sim.replayFrameMs * sim.replayFrames)
      currentTime = minTimeAvailable + sim.replayCurrentFrame * sim.replayFrameMs
    end
    for index, replay in ipairs(replayData) do
      local lag = sim.replayFrameMs * sim.replayPlaybackRate
      if (replay.time - lag) < currentTime and (replay.time + lag) > currentTime then
        local pos = vec3(replay.positionX, replay.positionY, replay.positionZ)
        if pos ~= slMgr.getTrackLightPosition or replay.rotation ~= replay.rotation then
          slMgr.setAndSaveTrackLights(pos, replay.rotation)
        end
        if replay.type == "start" then
          triggerStartLights(false)
        else
          falseStart(replay.type == "false_start")
        end
      end
    end
  end
  if isPaused then
    return
  end
  if sim.isOnlineRace and not sim.isAdmin then
    if ac.checkAdminPrivileges and checkAdminPrivilegesTimer > 10 then
      checkAdminPrivilegesTimer = 0
      ac.checkAdminPrivileges()
    end
    checkAdminPrivilegesTimer = checkAdminPrivilegesTimer + dt
  end
  slMgr.updateTime(ac.getGameDeltaT())
  slMgr.updateStartLights(ac.getGameDeltaT())
  if triggerStartLightsButton:pressed() then
    onStartLights()
  end
  if falseStartButton:pressed() then
    onFalseStart()
  end
end

function script.openWindowSettings(dt)
  ac.setWindowOpen("settings", true)
end
