local slMgr = require('start_lights_manager')
local tl = require('track_light')
local update = require('update_utils')
local DEFAULT_TRIGGER_RANGE = 20       -- in meters
local FALSE_START_TRIGGER_RANGE = 30
local DEFAULT_GREEN_LIGHT_DURATION = 2 -- in seconds
local DEFAULT_SCALE = 1                -- default scale for the start light
local DEFAULT_USE_SOUND = true         -- default sound setting
local AppSettings = ac.storage {
  useTriggerRange = true,
  triggerRange = DEFAULT_TRIGGER_RANGE,              -- in meters
  greenLightDuration = DEFAULT_GREEN_LIGHT_DURATION, -- in seconds
  classicLightsScale = DEFAULT_SCALE,                -- default scale for the start light
  useSound = DEFAULT_USE_SOUND,                      -- default sound setting
  classicLightsOrientation = "vertical",             -- default orientation for the start light
  useClassicLightsHUD = true,
  use3DLights = true,
  lightsModType = tl.LightType.DBZ,
  sendChatMessage = true,
}
local competitionMode = false ---@type boolean
local grantedUsers = table.new(5, 5)
local grantedUsersChanged ---@type boolean
local competitionModeChanged ---@type boolean
local unSavedGrantedUsers ---@type table
local unSavedCompetitionMode ---@type boolean
local friendlyCompetitionMode = false ---@type boolean
local replayDataCount = 0
local replayData ---@type table
local isPaused = false
local lastReplayPos = 0

slMgr.init(AppSettings.classicLightsScale, AppSettings.useSound, AppSettings.classicLightsOrientation,
  AppSettings.lightsModType, AppSettings.sendChatMessage, AppSettings.use3DLights)

update.init("Start_Lights", "https://raw.githubusercontent.com/Dasde/Start_Lights_updates/refs/heads/main/manifest.ini",
  "https://github.com/Dasde/Start_Lights_updates/raw/refs/heads/main/Start_Lights.zip")
update.checkForUpdate()
-- local triggerMessage = "[Start Lights] Get Ready!"
local triggerStartLightsButton = ac.ControlButton('Start_Lights_TRIGGER_START_LIGHTS',
  { keyboard = { key = (ui.KeyIndex.A) } })

-- local falseStartMessage = "[Start Lights] False start!"
-- local endFalseStartMessage = "[Start Lights] End false start!"
local falseStartButton = ac.ControlButton('Start_Lights_TOGGLE_FALSE_START',
  { keyboard = { key = (ui.KeyIndex.F) } })

local useWhiteList = false
local sim = ac.getSim()
local editionMode = false
local BUTTON_SIZE = vec2(150, 50)
--local EDIT_TEXT_SIZE = vec2(150,100)
local function readList(fileContent, list)
  list = list or {}
  table.clear(list)
  if not fileContent then return end
  for line in fileContent:gmatch("([^\n]*)\n?") do
    if line ~= "" then
      if line:match("^%s*#") then goto continue end -- skip comments
      local trimmed = line:match("^%s*(.-)%s*$")    -- trim whitespace
      if trimmed ~= "" then
        table.insert(list, trimmed)
        -- ac.log("Added to list " .. trimmed)
      end
      ::continue::
    end
  end
end

ac.uninstallApp("Traffic_Lights")

local whiteList = {}
if not io.exists(__dirname .. "/whiteList.txt") then
  -- ac.log("Creating default whiteList.txt")
  io.save(__dirname .. "/whiteList.txt", "# Add names to the whitelist, one per line\n# Example: John Doe\n")
end
local whiteListFile = io.load(__dirname .. "/whiteList.txt", nil)
readList(whiteListFile, whiteList)
if table.count(whiteList) > 0 then
  useWhiteList = true
else
  useWhiteList = false
end
ac.onFileChanged(__dirname .. "/whiteList.txt", function()
  whiteListFile = io.load(__dirname .. "/whiteList.txt", nil)
  readList(whiteListFile, whiteList)
  if #whiteList > 0 then
    useWhiteList = true
  else
    useWhiteList = false
  end
end)
local blackList = {}
if not io.exists(__dirname .. "/blackList.txt") then
  -- ac.log("Creating default blackList.txt")
  io.save(__dirname .. "/blackList.txt", "# Add names to the blackList, one per line\n# Example: John Doe\n")
end
local blackListFile = io.load(__dirname .. "/blackList.txt", nil)
readList(blackListFile, blackList)
ac.onFileChanged(__dirname .. "/blackList.txt", function()
  blackListFile = io.load(__dirname .. "/blackList.txt", nil)
  readList(blackListFile, blackList)
end)

local function verifySessionID(sessionID)
  return table.contains(grantedUsers, sessionID)
end

---Trigger the start lights
---@param isInitiator boolean
local function triggerStartLights(isInitiator)
  if slMgr.isYellowBlinking() then return end
  ac.setAppOpen("Start_Lights")
  ac.setAppWindowVisible("Start_Lights")
  ac.setWindowOpen("main", true)
  slMgr.triggerStartLights(AppSettings.greenLightDuration, isInitiator)
  if not sim.isReplayActive then
    local position = slMgr.getTrackLightPosition()
    local data = {
      type = "start",
      time = sim.currentSessionTime,
      positionX = position.x,
      positionY = position.y,
      positionZ = position.z,
      rotation = slMgr.getTrackLightsRotation()
    }
    replayDataCount = replayDataCount + 1
    ac.writeReplayBlob("start_lights_" .. replayDataCount, JSON.stringify(data))
    ac.writeReplayBlob("start_lights_count", replayDataCount)
  end
end

local function falseStart(start)
  if start then
    ac.setAppOpen("Start_Lights")
    ac.setAppWindowVisible("Start_Lights")
    ac.setWindowOpen("main", true)
  end
  slMgr.SetIsYellowBlinking(start)
  slMgr.setStartLightsVisible(start)
  if not sim.isReplayActive then
    local position = slMgr.getTrackLightPosition()
    local data = {
      type = start and "false_start" or "end_false_start",
      time = sim.currentSessionTime,
      positionX = position.x,
      positionY = position.y,
      positionZ = position.z,
      rotation = slMgr.getTrackLightsRotation()
    }
    replayDataCount = replayDataCount + 1
    ac.writeReplayBlob("start_lights_" .. replayDataCount, JSON.stringify(data))
    ac.writeReplayBlob("start_lights_count", replayDataCount)
  end
end

local function addGrantedUsers(sessionId)
  if not table.contains(grantedUsers, sessionId) then
    table.insert(grantedUsers, sessionId)
  end
end

local toggleCompetitionModeEvent = ac.OnlineEvent({
  key = ac.StructItem.key("Start_Lights_toggle_competition_events"),
  competitionMode = ac.StructItem.boolean(),
  grantedUsers = ac.StructItem.array(ac.StructItem.int8(), 10),
  lightPosition = ac.StructItem.vec3(),
  lightRotation = ac.StructItem.int8(),
  forceUpdate = ac.StructItem.boolean()
}, function(sender, data)
  if (competitionMode == data.competitionMode and sender.index == 0) then
    return
  end
  competitionMode = data.competitionMode
  if (not slMgr.trackHasLightMesh() or data.forceUpdate) and data.lightPosition and data.lightPosition ~= vec3() then
    slMgr.setAndSaveTrackLights(data.lightPosition, data.lightRotation)
  end
  table.clear(grantedUsers)
  addGrantedUsers(sender.sessionID)
  for i = 0, 10, 1 do
    addGrantedUsers(data.grantedUsers[i])
  end
  if data.competitionMode then
    ac.setMessage("Start Lights", "Competition Mode activated")
    friendlyCompetitionMode = false
  else
    ac.setMessage("Start Lights", "Competition Mode deactivated")
  end
end, ac.SharedNamespace.Global, false, { processPostponed = true })

local updateGrantedUsers = ac.OnlineEvent({
  key = ac.StructItem.key("Start_Lights_update_granted_users_events"),
  grantedUsers = ac.StructItem.array(ac.StructItem.int8(), 10),
}, function(sender, data)
  if (sender.index == 0) then
    return
  end
  table.clear(grantedUsers)
  addGrantedUsers(sender.sessionID)
  for i = 0, 10, 1 do
    addGrantedUsers(data.grantedUsers[i])
  end
end)

local startLightsEvent = ac.OnlineEvent({
  key = ac.StructItem.key("Start_Lights_trigger_events"),
  start = ac.StructItem.boolean(),
  falseStart = ac.StructItem.boolean(),
  endFalseStart = ac.StructItem.boolean(),
  lightPosition = ac.StructItem.vec3(),
  lightRotation = ac.StructItem.int8(),
}, function(sender, data)
  if data.endFalseStart then
    falseStart(false)
    return
  end
  if data.start or data.falseStart then
    if not competitionMode and not friendlyCompetitionMode and sender.index > 0 then
      local ourCarPosition = ac.getCar(0).position;
      local senderCarPostion = sender.position;
      local range = data.falseStart and FALSE_START_TRIGGER_RANGE or AppSettings.triggerRange
      local distance
      if slMgr.trackHasLightMesh() then
        distance = ourCarPosition:distance(slMgr.getTrackLightPosition())
      elseif data.lightPosition and data.lightPosition ~= vec3() then
        distance = ourCarPosition:distance(data.lightPosition)
        slMgr.setAndSaveTrackLights(data.lightPosition, data.lightRotation)
      else
        distance = ourCarPosition:distance(senderCarPostion)
      end
      if (AppSettings.useTriggerRange and distance > range) then
        return
      end
      local senderName = ac.getDriverName(sender.index)
      if useWhiteList then
        local isInWhiteList = false
        for _, name in ipairs(whiteList) do
          ---@diagnostic disable-next-line: need-check-nil
          if senderName:lower() == name:lower() then
            isInWhiteList = true
            break
          end
        end
        if not isInWhiteList then
          return
        end
      else
        for _, name in ipairs(blackList) do
          ---@diagnostic disable-next-line: need-check-nil
          if senderName:lower() == name:lower() then
            return
          end
        end
      end
    end
    if (competitionMode or friendlyCompetitionMode) and not slMgr.trackHasEmbedLightMesh() then
      if data.lightPosition ~= slMgr.getTrackLightPosition() or data.lightRotation ~= slMgr.getTrackLightsRotation() then
        slMgr.setAndSaveTrackLights(data.lightPosition, data.lightRotation)
      end
    end
    if data.falseStart then
      falseStart(true)
    else
      triggerStartLights(sender.index == 0)
    end
    return
  end
end)

local requestLightsData = ac.OnlineEvent({
  key = ac.StructItem.key("Start_Lights_trigger_events"),
}, function(sender, data)
  if (#grantedUsers > 0 and not (sim.isAdmin or verifySessionID(ac.getCar(0).sessionID))) or not slMgr.trackHasLightMesh() then
    return
  end
  toggleCompetitionModeEvent(
  { competitionMode = competitionMode, grantedUsers = grantedUsers, lightPosition = slMgr.getTrackLightPosition(), lightRotation =
  slMgr.getTrackLightsRotation() }, false, sender.sessionID)
end)
requestLightsData({})
local function onStartLights()
  if (sim.isOnlineRace) then
    if competitionMode then
      if (sim.isAdmin or verifySessionID(ac.getCar(0).sessionID)) then
        if slMgr.trackHasLightMesh() then
          startLightsEvent { start = true, falseStart = false, endFalseStart = false, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation() }
        else
          ac.setMessage("Start Lights", "No track light configured yet.", 'illegal')
        end
      else
        ac.setMessage("Start Lights", "Competition mode activated, only admins can operate the lights.", 'illegal')
      end
    elseif friendlyCompetitionMode then
      if slMgr.trackHasLightMesh() then
        startLightsEvent { start = true, falseStart = false, endFalseStart = false, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation() }
      else
        ac.setMessage("Start Lights", "No track light configured yet.", 'illegal')
      end
    elseif slMgr.trackHasLightMesh() then
      if ac.getCar(0).position:distance(slMgr.getTrackLightPosition()) <= AppSettings.triggerRange then
        startLightsEvent { start = true, falseStart = false, endFalseStart = false, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation() }
        -- ac.sendChatMessage(triggerMessage)
      else
        ac.setMessage("Start Lights", "You are too far.", 'illegal')
      end
    else
      startLightsEvent { start = true, falseStart = false, endFalseStart = false, lightPosition = nil, lightRotation = 0 }
      --ac.sendChatMessage(triggerMessage)
    end
  else
    --ac.log("Triggering Start lights in offline mode")
    triggerStartLights(true)
  end
end

local function onFalseStart()
  if (not slMgr.isYellowBlinking()) then
    if (sim.isOnlineRace) then
      if competitionMode then
        if (sim.isAdmin or verifySessionID(ac.getCar(0).sessionID)) then
          startLightsEvent { start = false, falseStart = true, endFalseStart = false, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation() }
        else
          ac.setMessage("Start Lights", "Competition mode activated, only admins can operate the lights.", 'illegal')
        end
      elseif friendlyCompetitionMode then
        startLightsEvent { start = false, falseStart = true, endFalseStart = false, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation() }
      elseif slMgr.trackHasLightMesh() then
        if ac.getCar(0).position:distance(slMgr.getTrackLightPosition()) <= FALSE_START_TRIGGER_RANGE then
          startLightsEvent { start = false, falseStart = true, endFalseStart = false, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation() }
          --ac.sendChatMessage(falseStartMessage)
        else
          ac.setMessage("Start Lights", "You are too far.", 'illegal')
        end
      else
        startLightsEvent { start = false, falseStart = true, endFalseStart = false, lightPosition = nil, lightRotation = 0 }
        --ac.sendChatMessage(falseStartMessage)
      end
    else
      falseStart(false)
    end
  else
    if (sim.isOnlineRace) then
      if competitionMode then
        if (sim.isAdmin or verifySessionID(ac.getCar(0).sessionID)) then
          startLightsEvent { start = false, falseStart = false, endFalseStart = true, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation() }
        else
          ac.setMessage("Start Lights", "Competition mode activated, only admins can operate the lights.", 'illegal')
        end
      elseif friendlyCompetitionMode then
        startLightsEvent { start = false, falseStart = false, endFalseStart = true, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation() }
      else
        startLightsEvent { start = false, falseStart = false, endFalseStart = true, lightPosition = nil, lightRotation = 0 }
        --ac.sendChatMessage(endFalseStartMessage)
      end
    else
      falseStart(false)
    end
  end
end

local function reloadReplayData()
  replayData = {}
---@diagnostic disable-next-line: cast-local-type
  replayDataCount = tonumber(ac.readReplayBlob("start_lights_count"))
  if replayDataCount and replayDataCount > 0 then
    for i = 1, replayDataCount + 1, 1 do
      local jdata = ac.readReplayBlob("start_lights_" .. i)
---@diagnostic disable-next-line: param-type-mismatch
      local data = JSON.parse(jdata)
      table.insert(replayData, data)
    end
  end
end

if sim.isReplayActive then
  reloadReplayData()
end

ac.onClientDisconnected(function(connectedCarIndex, connectedSessionID)
  if not verifySessionID(connectedSessionID) then return end
  if (sim.isAdmin or verifySessionID(ac.getCar(0).sessionID)) then
    table.removeItem(grantedUsers, connectedSessionID)
    updateGrantedUsers({ grantedUsers = grantedUsers }, true)
  elseif #grantedUsers == 1 then
    table.clear(grantedUsers)
    competitionMode = false
  end
end)

function script.windowCompetitionMode(dt)
  if not (sim.isAdmin or verifySessionID(ac.getCar(0).sessionID)) then
    do return end
  end
  local bgSize = (slMgr.isStartLightsActive() or slMgr.isYellowBlinking()) and ui.windowSize():clone():add(vec2(0, -70)) or
  ui.windowSize()
  --ui.drawRectFilled(vec2(0, 0), bgSize, rgbm(0, 0, 0, 0.15))
  ui.drawRect(vec2(0, 0), bgSize, rgbm(0.6, 0.6, 0.6, 0.15))
  ui.newLine(8)
  ui.pushFont(ui.Font.Title)
  ui.setNextItemWidth(450)
  ui.setCursorX(20)
  ui.text("Traffic Lights - Competition Mode    ")
  ui.setCursorX(20)
  if competitionMode then
    ui.textColored("Activated", rgbm.colors.red)
  else
    ui.textColored("Not Activated", rgbm.colors.gray)
  end
  ui.popFont()
  ui.newLine(2)
  ui.setCursorX(20)
  script.windowContentCompetitionMode(dt)
  if slMgr.isStartLightsActive() or slMgr.isYellowBlinking() then
    ui.childWindow("mini-hud", vec2(ui.windowWidth(), 85), function()
      slMgr.drawMiniHUD()
    end)
  end
end

function script.windowContentCompetitionMode(dt)
  if sim.isAdmin or verifySessionID(ac.getCar(0).sessionID) then
    local windowCursor = 20

    if slMgr.trackHasLightMesh() then
      if ui.button("Force update start light position") then
        toggleCompetitionModeEvent { competitionMode = competitionMode, grantedUsers = grantedUsers, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation(), forceUpdate = true }
      end
    end

    if not competitionModeChanged then
      unSavedCompetitionMode = competitionMode
    end
    ui.setCursorX(windowCursor)
    if ui.checkbox("Toggle Competition Mode", unSavedCompetitionMode) then
      unSavedCompetitionMode = not unSavedCompetitionMode
      competitionModeChanged = true
    end
    if (sim.isAdmin) then
      ui.setCursorX(windowCursor)
      ui.text("Lights operators :")
      if not grantedUsersChanged then
        unSavedGrantedUsers = table.clone(grantedUsers)
      end
      for i, car in ac.iterateCars() do
        local checked = car.index == 0 or table.contains(unSavedGrantedUsers, car.sessionID)
        ui.setCursorX(windowCursor)
        if car.isConnected then
          ---@diagnostic disable-next-line: param-type-mismatch
          if ui.checkbox(ac.getDriverName(car.index), checked) then
            checked = not checked
            grantedUsersChanged = true
            if checked then
              table.insert(unSavedGrantedUsers, car.sessionID)
            else
              table.removeItem(unSavedGrantedUsers, car.sessionID)
            end
          end
        end
      end
      grantedUsersChanged = not table.same(grantedUsers, unSavedGrantedUsers)
    else
      grantedUsersChanged = false
      unSavedGrantedUsers = table.clone(grantedUsers)
    end
    ui.newLine(15)
    competitionModeChanged = (competitionMode ~= unSavedCompetitionMode)
    local buttonSize = vec2(120, 50)
    if (grantedUsersChanged or competitionModeChanged) then
      ui.setCursorX(30)
      if ui.button("Validate", buttonSize) then
        grantedUsers = table.clone(unSavedGrantedUsers)
        if competitionModeChanged then
          --competitionMode = unSavedCompetitionMode
          toggleCompetitionModeEvent { competitionMode = unSavedCompetitionMode, grantedUsers = grantedUsers, lightPosition = slMgr.getTrackLightPosition(), lightRotation = slMgr.getTrackLightsRotation() }
          competitionModeChanged = false
          grantedUsersChanged = false
        else
          updateGrantedUsers { grantedUsers = grantedUsers }
          grantedUsersChanged = false
        end
      end
      ui.sameLine(0, ui.windowWidth() - 300)
      if ui.button("Cancel", buttonSize) then
        competitionModeChanged = false
        grantedUsersChanged = false
      end
      ui.newLine(10)
    end
    if not competitionMode then
      ui.setNextTextBold()
      ui.text("Friendly Competition Mode")
      ui.text("This mode is for friendly battles, every driver can activate the start lights.")
      ui.text("The lights will be only activated for those with that mode activated")
      if ui.checkbox("Toggle Friendly Competition Mode", friendlyCompetitionMode) then
        friendlyCompetitionMode = not friendlyCompetitionMode
      end
    end
    if competitionMode or friendlyCompetitionMode then
      ui.setCursorX(30)
      if ui.button("Trigger Start!", buttonSize) then
        onStartLights()
      end
      ui.sameLine(0, ui.windowWidth() - 300)
      if ui.button("False Start!", buttonSize) then
        onFalseStart()
      end
      ui.newLine(10)
    end
  end
end

function script.windowSettings(dt)
  if competitionMode then
    ui.pushFont(ui.Font.Huge)
    ui.setNextTextBold()
    ui.textColored("Competition Mode Activated!", rgbm.colors.red)
    ui.popFont()
  end
  ui.pushFont(ui.Font.Title)
  ui.tabBar("settings", function()
    ui.tabItem("General", function()
      ui.text("Orientation :")
      if ui.radioButton("Vertical", AppSettings.classicLightsOrientation == "vertical") then
        AppSettings.classicLightsOrientation = "vertical"
        slMgr.setOrientation(AppSettings.classicLightsOrientation)
        script.resizeWindowMain()
      end
      if ui.radioButton("Horizontal", AppSettings.classicLightsOrientation == "horizontal") then
        AppSettings.classicLightsOrientation = "horizontal"
        slMgr.setOrientation(AppSettings.classicLightsOrientation)
        script.resizeWindowMain()
      end
      if ui.checkbox("Use Trigger Range", AppSettings.useTriggerRange) then
        AppSettings.useTriggerRange = not AppSettings.useTriggerRange
      end
      if AppSettings.useTriggerRange then
        AppSettings.triggerRange = ui.slider("Trigger Range (m)", AppSettings.triggerRange, 1, 100)
      else
        AppSettings.triggerRange = DEFAULT_TRIGGER_RANGE -- reset to default if not using range
      end
      AppSettings.greenLightDuration = ui.slider("Green Light Duration (s)", AppSettings.greenLightDuration, 1, 10)
      local scaleChanged
      AppSettings.classicLightsScale, scaleChanged = ui.slider("Start Light Scale", AppSettings.classicLightsScale, 0.1,
        3)
      if scaleChanged then
        slMgr.setScale(AppSettings.classicLightsScale)
        script.resizeWindowMain()
      end
      if ui.checkbox("Use Sound", AppSettings.useSound) then
        AppSettings.useSound = not AppSettings.useSound
        slMgr.setUseSound(AppSettings.useSound)
      end
      if ui.checkbox("Display classic lights HUD", AppSettings.useClassicLightsHUD) then
        AppSettings.useClassicLightsHUD = not AppSettings.useClassicLightsHUD
        slMgr.setUseClassicLightsHUD(AppSettings.useClassicLightsHUD)
      end
      if ui.checkbox("Send chat message to non user of the app (Get Ready,1,2,3,Go!)", AppSettings.sendChatMessage) then
        AppSettings.sendChatMessage = not AppSettings.sendChatMessage
        slMgr.setSendChatMessage(AppSettings.sendChatMessage)
      end
      if ui.checkbox("Display 3D Lights in front of car. (if there are no lights on track already)", AppSettings.use3DLights) then
        AppSettings.use3DLights = not AppSettings.use3DLights
        slMgr.setUse3DLights(AppSettings.use3DLights)
      end
      if AppSettings.use3DLights and io.fileExists(ac.getFolder(ac.FolderID.ContentCars) .. "/vdm_lights/vdm_lights.kn5") then
        ui.text("Choose your start lights :")
        local selectedDBZMod = (AppSettings.lightsModType == tl.LightType.DBZ)
        if ui.radioButton("DBZ", selectedDBZMod) then
          AppSettings.lightsModType = not selectedDBZMod and tl.LightType.DBZ or tl.LightType.VDM
        end
        local selectedVDMMod = (AppSettings.lightsModType == tl.LightType.VDM)
        if ui.radioButton("VDM", selectedVDMMod) then
          AppSettings.lightsModType = not selectedVDMMod and tl.LightType.VDM or tl.LightType.DBZ
        end
        slMgr.set3DModType(AppSettings.lightsModType)
        slMgr.reloadTrackLights(true)
      end
      ui.separator()
      ui.setNextTextBold()
      ui.text("How to trigger the start lights")
      if competitionMode and not (sim.isAdmin or verifySessionID(ac.getCar(0).sessionID)) then
        ui.textColored("Not available in Competion Mode", rgbm.colors.red)
      end
      local configuredControl = triggerStartLightsButton:boundTo()
      if not configuredControl then
        ui.text(
          "The control to start the lights isn't configured yet. Configure it with Extended Controls (Apps/Start Lights)")
      else
        ui.text("Press " .. configuredControl .. " to start the lights")
      end
      ui.setNextTextBold()
      ui.text("How to trigger false start")
      configuredControl = falseStartButton:boundTo()
      if not configuredControl then
        ui.text(
          "The control to trigger a false start isn't configured yet. Configure it with Extended Controls (Apps/Start Lights)")
      else
        ui.text("Press " .. configuredControl .. " to trigger a false start")
      end
      ui.separator()
      ui.text("You can change the controls with the Extended Controls app (Apps/Start Lights)")
      if ui.button("Open Extended Controls") then
        ac.setAppOpen("ext_controls")
        ac.setAppWindowVisible("ext_controls")
      end
      ui.separator()
      ui.setNextTextBold()
      ui.text("Whitelist and Blacklist Settings")
      if useWhiteList then
        ui.text("Whitelist is enabled. Only players in the whitelist can operate the start lights.")
      else
        ui.text("Whitelist is disabled. All players can operate the start lights.")
      end
      if #whiteList > 0 then
        ui.text("Whitelist: " .. table.concat(whiteList, ", "))
      else
        ui.text("Whitelist is empty.")
      end
      if #blackList > 0 then
        ui.text("Blacklist: " .. table.concat(blackList, ", "))
      else
        ui.text("Blacklist is empty.")
      end
      if ui.button("Open Whitelist") then
        os.openInExplorer(__dirname .. "/whiteList.txt")
      end
      ui.sameLine(170)
      if ui.button("Open Blacklist") then
        os.openInExplorer(__dirname .. "/blackList.txt")
      end
      ui.separator()
      ui.newLine(20)
      if ui.button("Restart app...", BUTTON_SIZE) then
        ac.restartApp()
      end
    end)
    ui.tabItem("Track light editor", function()
      if slMgr.trackHasLightMesh() then
        ui.text(string.format("A track start light is already on track at position\n%s.", slMgr.getTrackLightPosition()))
        ui.separator()
        ui.newLine(15)
      else
        ui.text("There is no track start light on track.\nIf you have track_lights.ini paste it in the ")
        ui.separator()
        ui.newLine(5)
        ui.text(
          "If you have a track_lights.ini file for the track paste it in the track extension folder and restart the app.")
        ui.separator()
        ui.newLine(15)
        if ui.button("Restart app...", BUTTON_SIZE) then
          ac.restartApp()
        end
        ui.sameLine(0, 0)
      end

      ui.setCursorX(ui.getCursorX() +
        ((ui.windowWidth() - ui.getCursorX() - 300 + (editionMode and 0 or -BUTTON_SIZE.x - 40)) / 2))
      if ui.button("Open track extension folder...", vec2(300, BUTTON_SIZE.y)) then
        local trackExtFolder = ac.getFolder(ac.FolderID.CurrentTrack) .. "/extension/"
        local trackIniFilename = ac.getFolder(ac.FolderID.CurrentTrack) .. "/extension/" .. "track_lights.ini"
        if io.exists(trackIniFilename) then
          os.showInExplorer(trackIniFilename)
        else
          if not io.exists(trackExtFolder) then
            io.createDir(trackExtFolder)
          end
          os.openInExplorer(trackExtFolder)
        end
      end
      if editionMode then
        ui.setMouseCursor(ui.MouseCursor.ResizeAll)
        ui.separator()
        ui.newLine(5)
        ui.text(
          "Just double click on the map where you want to place the start lights.\nClick the save button when you are done.")
        ui.newLine(15)
        local rot = refnumber(slMgr.getTrackLightsRotation())
        ui.setNextItemWidth(350)
        ui.setCursorX((ui.windowWidth() - 350) / 2)
        if ui.slider("'##rotationSliderID'", rot, 0, 360, 'Rotation: %.1f') then
          slMgr.rotateTrackLights(rot.value)
        end
        ui.newLine(5)
        ui.setCursorX((ui.windowWidth() - (2 * BUTTON_SIZE.x) - 10) / 2)
        if ui.button("Save", BUTTON_SIZE) then
          editionMode = false
          slMgr.trackLightEdition(editionMode)
          slMgr.saveTrackLights()
        end
        ui.sameLine()
        if ui.button("Cancel", BUTTON_SIZE) then
          editionMode = false
          slMgr.trackLightEdition(editionMode)
          slMgr.reloadTrackLights(false)
        end
      else
        ui.setMouseCursor(ui.MouseCursor.Arrow)
        if slMgr.trackHasEmbedLightMesh() then
          ui.text("This track has its own start lights already. It's not editable.")
        else
          ui.sameLine(0, 0)
          ui.setCursorX(ui.getCursorX() + (ui.windowWidth() - ui.getCursorX() - BUTTON_SIZE.x) / 2)
          if ui.button(slMgr.trackHasLightMesh() and "Edit Light..." or "Create Light...", BUTTON_SIZE) then
            editionMode = true
            slMgr.trackLightEdition(editionMode)
          end
        end
      end
    end)
    if sim.isAdmin or verifySessionID(ac.getCar(0).sessionID) then
      ui.tabItem("Competition Mode", function()
        script.windowContentCompetitionMode(dt)
      end)
    elseif competitionMode then
      ui.tabItem("Competition Mode", function()
        ui.pushFont(ui.Font.Huge)
        ui.setNextTextBold()
        ui.textColored("Competition Mode Activated!", rgbm.colors.red)
        ui.popFont()
        ui.text("Only admins can operate the Track Lights")
      end)
    end
    ui.tabItem("Updates", function()
      update.drawUI()
    end)
  end)
  ui.popFont()
end

function script.resizeWindowMain()
  local size = AppSettings.classicLightsOrientation == "vertical" and
      vec2(math.max(80 * AppSettings.classicLightsScale, 200), math.max(300 * AppSettings.classicLightsScale, 50)) or
      vec2(math.max(300 * AppSettings.classicLightsScale, 200), math.max(80 * AppSettings.classicLightsScale, 50))
  ac.setWindowSizeConstraints("main", size, size)
end

function script.windowMain(dt)
  if (slMgr.isStartLightsActive() or slMgr.isYellowBlinking()) then
    script.drawUI(dt)
  else
    if ui.windowHovered(bit.bor(ui.HoveredFlags.RootAndChildWindows, ui.HoveredFlags.AllowWhenBlockedByActiveItem)) then
      slMgr.setStartLightsVisible(true)
      script.drawUI(dt)
      if not ac.isWindowOpen("settings") then
        ui.offsetCursorY((ui.windowHeight() - 50) / 2)
        ui.offsetCursorX((ui.windowWidth() - 200) / 2)
        if ui.button("Show Start Lights settings...", vec2(200, 50)) then
          script.openWindowSettings(dt)
        end
      end
    else
      slMgr.setStartLightsVisible(false)
    end
  end
end

function script.drawUI(dt)
  slMgr.draw()
end

ac.onSessionStart(function(sessionIndex, restarted)
  if restarted then
    replayDataCount = 0
    ac.writeReplayBlob("start_lights_count", 0)
    reloadReplayData()
  end
end)

ac.onChatMessage(function(message, senderCarIndex, senderSessionID)
  if message == "1" or message == "2" or message == "3" or message == "Go!" then
    return true
    ---@diagnostic disable-next-line: missing-return
  end
end)

function script.update(dt)
  isPaused = ac.getGameDeltaT() == 0
  if sim.isReplayActive then
    reloadReplayData()
    local currentTime
    local replayPos = sim.replayFrames - sim.replayCurrentFrame
    if replayPos > lastReplayPos + 5 or replayPos < lastReplayPos - 5 then
      -- seeking in the replay timeline
      slMgr.stopStartLights()
    end
    lastReplayPos = replayPos
    if sim.isReplayOnlyMode then
      currentTime = sim.currentSessionTime
    else
      local minTimeAvailable = sim.currentSessionTime - (sim.replayFrameMs * sim.replayFrames)
      currentTime = minTimeAvailable + sim.replayCurrentFrame * sim.replayFrameMs
    end
    for index, replay in ipairs(replayData) do
      local lag = sim.replayFrameMs * sim.replayPlaybackRate
      if (replay.time - lag) < currentTime and (replay.time + lag) > currentTime then
        local pos = vec3(replay.positionX, replay.positionY, replay.positionZ)
        if pos ~= slMgr.getTrackLightPosition or replay.rotation ~= replay.rotation then
          slMgr.setAndSaveTrackLights(pos, replay.rotation)
        end
        if replay.type == "start" then
          triggerStartLights(false)
        else
          falseStart(replay.type == "false_start")
        end
      end
    end
  end
  if isPaused then
    return
  end
  slMgr.updateTime(ac.getGameDeltaT())
  slMgr.updateStartLights(ac.getGameDeltaT())
  if triggerStartLightsButton:pressed() then
    onStartLights()
  end
  if falseStartButton:pressed() then
    onFalseStart()
  end
end

function script.openWindowSettings(dt)
  ac.setWindowOpen("settings", true)
end
