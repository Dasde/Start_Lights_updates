local lhud = {}
local colors = {
    GRAY = rgbm(0.2, 0.2, 0.2, 1),
    LIGHT_GREEN = rgbm(0, 1, 0, 1),
    YELLOW = rgbm(1, 1, 0, 1),
    RED = rgbm(1, 0, 0, 1),
    GREEN = rgbm(0, 1, 0, 1),
    WHITE = rgbm(1, 1, 1, 1),
    BLACK = rgbm(0, 0, 0, 0.5),
    TRANSPARENT = rgbm(0, 0, 0, 0),
    NEON_RED = rgbm(1, 0, 0, 0.9),
    DARK_GRAY = rgbm(0.1, 0.1, 0.1, 0.3),
}

local light_animations = {}

for i = 1, 4 do
    light_animations[i] = {
        alpha = 0,
        scale = 0.5,
        active = false
    }
end

function lhud.displayLights()
    lhud.configureLights(1, 1, true)
    for i = 1, 4 do
        light_animations[i].active = true
        light_animations[i].alpha = 1
        light_animations[i].scale = 1
    end
end

function lhud.hideLights()
    lhud.configureLights(0, 0.5, false)
end

function lhud.configureLights(alpha, scale, active)
    for i = 1, 4 do
        light_animations[i].alpha = alpha
        light_animations[i].scale = scale
        light_animations[i].active = active
    end
end

function lhud.configureLight(lightId, alpha, scale, active)
    light_animations[lightId].alpha = alpha
    light_animations[lightId].scale = scale
    light_animations[lightId].active = active
end

function lhud.fadeInLights(dt)
    for i = 1, 4 do
        if light_animations[i].active then
            light_animations[i].alpha = math.min(light_animations[i].alpha + dt * 12, 1)
            light_animations[i].scale = math.min(light_animations[i].scale + dt * 12, 1)
            if light_animations[i].alpha >= 1 and light_animations[i].scale >= 1 then
                light_animations[i].active = false
            end
        end
    end
end

local function drawBlurredCircle(center, radius, color, blur_strength)
    local blur_layers = 5
    for layer = blur_layers, 1, -1 do
        local layer_scale = 1 + (layer / blur_layers) * (blur_strength / 100)
        local layer_alpha = color.mult * (1 - (layer - 1) / blur_layers) * 0.2
        local blur_radius = radius * layer_scale
        local blur_color = rgbm(color.r, color.g, color.b, layer_alpha)
        ui.drawCircleFilled(center, blur_radius, blur_color, 64)
    end
    ui.drawCircleFilled(center, radius, color, 64)
end

function lhud.draw(orientation, hud_scale, traffic_light_state, isYellowBlinking)
    local traffic_light_size = orientation == "vertical" and vec2(80 * hud_scale, 300 * hud_scale) or
        vec2(300 * hud_scale, 80 * hud_scale)
    local traffic_light_pos = vec2(0, 0)
    ui.drawRectFilled(traffic_light_pos, traffic_light_pos + traffic_light_size, colors.BLACK, 10 * hud_scale)
    local light_radius = 30 * hud_scale
    local light_spacing = 13 * hud_scale
    local light_positions = {}
    for i = 1, 4 do
        local y = traffic_light_pos.y + (i - 1) * (light_radius * 2 + light_spacing) + light_spacing
        local center
        if (orientation == 'vertical') then
            center = vec2(traffic_light_pos.x + traffic_light_size.x / 2, y + light_radius)
        else
            center = vec2(y + light_radius, traffic_light_size.y / 2)
        end
        table.insert(light_positions, center)
    end
    for i, center in ipairs(light_positions) do
        ui.drawCircleFilled(center, light_radius, colors.DARK_GRAY, 64)
    end

    if not isYellowBlinking then
        for i = 1, 4 do
            if light_animations[i].active then
                light_animations[i].alpha = math.min(light_animations[i].alpha + ui.deltaTime() * 2, 1)
                light_animations[i].scale = math.min(light_animations[i].scale + ui.deltaTime() * 2, 1)
                if light_animations[i].alpha >= 1 and light_animations[i].scale >= 1 then
                    light_animations[i].active = false
                end
            end
        end
    end

    for i, center in ipairs(light_positions) do
        local color
        if isYellowBlinking then
            color = colors.YELLOW
        else
            if traffic_light_state < 4 then
                if i <= traffic_light_state then
                    color = colors.RED
                end
            elseif traffic_light_state == 4 then
                if i == 4 then
                    color = colors.GREEN
                end
            end
        end

        if color then
            local anim = light_animations[i]
            local alpha = anim and anim.alpha or 1
            local scale = anim and anim.scale or 1
            local draw_color = rgbm(color.r, color.g, color.b, alpha)
            local draw_radius = light_radius * scale
            drawBlurredCircle(center, draw_radius, draw_color, 15)
        end
    end
end

return lhud
